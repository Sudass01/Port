import { getIconData, iconToSVG, replaceIDs } from '@iconify/utils';
import lucide from '@iconify-json/lucide/icons.json';
import type { IconifyJSON } from '@iconify/types';

/** Ícones de marca que não existem no Lucide (desenhados em 24x24). */
const custom: Record<string, { body: string; filled?: boolean }> = {
  whatsapp: {
    filled: true,
    body: '<path fill="currentColor" d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.2h.01c5.46 0 9.91-4.45 9.91-9.91A9.85 9.85 0 0 0 12.04 2Zm0 18.15h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.25-8.23a8.2 8.2 0 0 1 8.23 8.24c0 4.54-3.7 8.23-8.23 8.23Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.13-.15.17-.25.25-.42.08-.17.04-.31-.02-.43-.06-.13-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48a.92.92 0 0 0-.66.31c-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.1-.22-.16-.47-.29Z"/>',
  },
};

const cache = new Map<string, string>();

/** Retorna o SVG (string) de um ícone do Lucide ou dos ícones de marca. Resolvido no build: zero JS no navegador. */
export function iconSvg(name: string, size = 24, strokeWidth = 1.75, extraClass = ''): string {
  const key = `${name}|${size}|${strokeWidth}|${extraClass}`;
  const hit = cache.get(key);
  if (hit) return hit;

  let body: string;
  if (custom[name]) {
    body = custom[name].body;
  } else {
    const data = getIconData(lucide as IconifyJSON, name);
    if (!data) throw new Error(`[icons] Ícone "${name}" não encontrado no Lucide. Veja https://lucide.dev/icons`);
    const svg = iconToSVG(data, { height: size, width: size });
    body = replaceIDs(svg.body).replace(/stroke-width="2"/g, `stroke-width="${strokeWidth}"`);
  }
  const cls = ['icon', extraClass].filter(Boolean).join(' ');
  const html = `<svg xmlns="http://www.w3.org/2000/svg" class="${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${body}</svg>`;
  cache.set(key, html);
  return html;
}
