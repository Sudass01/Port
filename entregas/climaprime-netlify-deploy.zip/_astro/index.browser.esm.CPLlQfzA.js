const mr=()=>{};var ze={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vn=function(n){const t=[];let e=0;for(let r=0;r<n.length;r++){let s=n.charCodeAt(r);s<128?t[e++]=s:s<2048?(t[e++]=s>>6|192,t[e++]=s&63|128):(s&64512)===55296&&r+1<n.length&&(n.charCodeAt(r+1)&64512)===56320?(s=65536+((s&1023)<<10)+(n.charCodeAt(++r)&1023),t[e++]=s>>18|240,t[e++]=s>>12&63|128,t[e++]=s>>6&63|128,t[e++]=s&63|128):(t[e++]=s>>12|224,t[e++]=s>>6&63|128,t[e++]=s&63|128)}return t},gr=function(n){const t=[];let e=0,r=0;for(;e<n.length;){const s=n[e++];if(s<128)t[r++]=String.fromCharCode(s);else if(s>191&&s<224){const i=n[e++];t[r++]=String.fromCharCode((s&31)<<6|i&63)}else if(s>239&&s<365){const i=n[e++],a=n[e++],d=n[e++],m=((s&7)<<18|(i&63)<<12|(a&63)<<6|d&63)-65536;t[r++]=String.fromCharCode(55296+(m>>10)),t[r++]=String.fromCharCode(56320+(m&1023))}else{const i=n[e++],a=n[e++];t[r++]=String.fromCharCode((s&15)<<12|(i&63)<<6|a&63)}}return t.join("")},Vn={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,t){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const e=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let s=0;s<n.length;s+=3){const i=n[s],a=s+1<n.length,d=a?n[s+1]:0,m=s+2<n.length,g=m?n[s+2]:0,y=i>>2,I=(i&3)<<4|d>>4;let A=(d&15)<<2|g>>6,S=g&63;m||(S=64,a||(A=64)),r.push(e[y],e[I],e[A],e[S])}return r.join("")},encodeString(n,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(n):this.encodeByteArray(vn(n),t)},decodeString(n,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(n):gr(this.decodeStringToByteArray(n,t))},decodeStringToByteArray(n,t){this.init_();const e=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let s=0;s<n.length;){const i=e[n.charAt(s++)],d=s<n.length?e[n.charAt(s)]:0;++s;const g=s<n.length?e[n.charAt(s)]:64;++s;const I=s<n.length?e[n.charAt(s)]:64;if(++s,i==null||d==null||g==null||I==null)throw new _r;const A=i<<2|d>>4;if(r.push(A),g!==64){const S=d<<4&240|g>>2;if(r.push(S),I!==64){const v=g<<6&192|I;r.push(v)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class _r extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const yr=function(n){const t=vn(n);return Vn.encodeByteArray(t,!0)},xt=function(n){return yr(n).replace(/\./g,"")},Er=function(n){try{return Vn.decodeString(n,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ir(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ar=()=>Ir().__FIREBASE_DEFAULTS__,wr=()=>{if(typeof process>"u"||typeof ze>"u")return;const n=ze.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},br=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const t=n&&Er(n[1]);return t&&JSON.parse(t)},Ae=()=>{try{return mr()||Ar()||wr()||br()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},Tr=n=>Ae()?.emulatorHosts?.[n],vr=n=>{const t=Tr(n);if(!t)return;const e=t.lastIndexOf(":");if(e<=0||e+1===t.length)throw new Error(`Invalid host ${t} with no separate hostname and port!`);const r=parseInt(t.substring(e+1),10);return t[0]==="["?[t.substring(1,e-1),r]:[t.substring(0,e),r]},Sn=()=>Ae()?.config,yo=n=>Ae()?.[`_${n}`];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vr{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}wrapCallback(t){return(e,r)=>{e?this.reject(e):this.resolve(r),typeof t=="function"&&(this.promise.catch(()=>{}),t.length===1?t(e):t(e,r))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sr(n,t){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const e={alg:"none",type:"JWT"},r=t||"demo-project",s=n.iat||0,i=n.sub||n.user_id;if(!i)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const a={iss:`https://securetoken.google.com/${r}`,aud:r,iat:s,exp:s+3600,auth_time:s,sub:i,user_id:i,firebase:{sign_in_provider:"custom",identities:{}},...n};return[xt(JSON.stringify(e)),xt(JSON.stringify(a)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nn(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Eo(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Nn())}function Io(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function Ao(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function wo(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function bo(){const n=Nn();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function Nr(){try{return typeof indexedDB=="object"}catch{return!1}}function Rr(){return new Promise((n,t)=>{try{let e=!0;const r="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(r);s.onsuccess=()=>{s.result.close(),e||self.indexedDB.deleteDatabase(r),n(!0)},s.onupgradeneeded=()=>{e=!1},s.onerror=()=>{t(s.error?.message||"")}}catch(e){t(e)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pr="FirebaseError";class ft extends Error{constructor(t,e,r){super(e),this.code=t,this.customData=r,this.name=Pr,Object.setPrototypeOf(this,ft.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Rn.prototype.create)}}class Rn{constructor(t,e,r){this.service=t,this.serviceName=e,this.errors=r}create(t,...e){const r=e[0]||{},s=`${this.service}/${t}`,i=this.errors[t],a=i?Dr(i,r):"Error",d=`${this.serviceName}: ${a} (${s}).`;return new ft(s,d,r)}}function Dr(n,t){try{let e=0,r="";for(;e<n.length;){const s=n.indexOf("{$",e);if(s===-1){r+=n.substring(e);break}const i=n.indexOf("}",s+2);if(i===-1){r+=n.substring(e);break}const a=n.substring(s+2,i),d=t[a];r+=n.substring(e,s)+(d!=null?String(d):`<${a}?>`),e=i+1}return r}catch{return n}}function To(n){for(const t in n)if(Object.prototype.hasOwnProperty.call(n,t))return!1;return!0}function Lt(n,t){if(n===t)return!0;const e=Object.keys(n),r=Object.keys(t);for(const s of e){if(!r.includes(s))return!1;const i=n[s],a=t[s];if(qe(i)&&qe(a)){if(!Lt(i,a))return!1}else if(i!==a)return!1}for(const s of r)if(!e.includes(s))return!1;return!0}function qe(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vo(n){const t=[];for(const[e,r]of Object.entries(n))Array.isArray(r)?r.forEach(s=>{t.push(encodeURIComponent(e)+"="+encodeURIComponent(s))}):t.push(encodeURIComponent(e)+"="+encodeURIComponent(r));return t.length?"&"+t.join("&"):""}function Vo(n){const t={};return n.replace(/^\?/,"").split("&").forEach(r=>{if(r){const[s,i]=r.split("=");t[decodeURIComponent(s)]=decodeURIComponent(i)}}),t}function So(n){const t=n.indexOf("?");if(!t)return"";const e=n.indexOf("#",t);return n.substring(t,e>0?e:void 0)}function No(n,t){const e=new Cr(n,t);return e.subscribe.bind(e)}class Cr{constructor(t,e){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=e,this.task.then(()=>{t(this)}).catch(r=>{this.error(r)})}next(t){this.forEachObserver(e=>{e.next(t)})}error(t){this.forEachObserver(e=>{e.error(t)}),this.close(t)}complete(){this.forEachObserver(t=>{t.complete()}),this.close()}subscribe(t,e,r){let s;if(t===void 0&&e===void 0&&r===void 0)throw new Error("Missing Observer.");Or(t,["next","error","complete"])?s=t:s={next:t,error:e,complete:r},s.next===void 0&&(s.next=re),s.error===void 0&&(s.error=re),s.complete===void 0&&(s.complete=re);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?s.error(this.finalError):s.complete()}catch{}}),this.observers.push(s),i}unsubscribeOne(t){this.observers===void 0||this.observers[t]===void 0||(delete this.observers[t],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(t){if(!this.finalized)for(let e=0;e<this.observers.length;e++)this.sendOne(e,t)}sendOne(t,e){this.task.then(()=>{if(this.observers!==void 0&&this.observers[t]!==void 0)try{e(this.observers[t])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(t){this.finalized||(this.finalized=!0,t!==void 0&&(this.finalError=t),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function Or(n,t){if(typeof n!="object"||n===null)return!1;for(const e of t)if(e in n&&typeof n[e]=="function")return!0;return!1}function re(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function W(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pn(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function kr(n){return(await fetch(n,{credentials:"include"})).ok}class _t{constructor(t,e,r){this.name=t,this.instanceFactory=e,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nt="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fr{constructor(t,e){this.name=t,this.container=e,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const e=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(e)){const r=new Vr;if(this.instancesDeferred.set(e,r),this.isInitialized(e)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:e});s&&r.resolve(s)}catch{}}return this.instancesDeferred.get(e).promise}getImmediate(t){const e=this.normalizeInstanceIdentifier(t?.identifier),r=t?.optional??!1;if(this.isInitialized(e)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:e})}catch(s){if(r)return null;throw s}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,!!this.shouldAutoInitialize()){if(xr(t))try{this.getOrInitializeService({instanceIdentifier:nt})}catch{}for(const[e,r]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(e);try{const i=this.getOrInitializeService({instanceIdentifier:s});r.resolve(i)}catch{}}}}clearInstance(t=nt){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(e=>"INTERNAL"in e).map(e=>e.INTERNAL.delete()),...t.filter(e=>"_delete"in e).map(e=>e._delete())])}isComponentSet(){return this.component!=null}isInitialized(t=nt){return this.instances.has(t)}getOptions(t=nt){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:e={}}=t,r=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:r,options:e});for(const[i,a]of this.instancesDeferred.entries()){const d=this.normalizeInstanceIdentifier(i);r===d&&a.resolve(s)}return s}onInit(t,e){const r=this.normalizeInstanceIdentifier(e),s=this.onInitCallbacks.get(r)??new Set;s.add(t),this.onInitCallbacks.set(r,s);const i=this.instances.get(r);return i&&t(i,r),()=>{s.delete(t)}}invokeOnInitCallbacks(t,e){const r=this.onInitCallbacks.get(e);if(r)for(const s of r)try{s(t,e)}catch{}}getOrInitializeService({instanceIdentifier:t,options:e={}}){let r=this.instances.get(t);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:Mr(t),options:e}),this.instances.set(t,r),this.instancesOptions.set(t,e),this.invokeOnInitCallbacks(r,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,r)}catch{}return r||null}normalizeInstanceIdentifier(t=nt){return this.component?this.component.multipleInstances?t:nt:t}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Mr(n){return n===nt?void 0:n}function xr(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lr{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const e=this.getProvider(t.name);if(e.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);e.setComponent(t)}addOrOverwriteComponent(t){this.getProvider(t.name).isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const e=new Fr(t,this);return this.providers.set(t,e),e}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var b;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(b||(b={}));const Ur={debug:b.DEBUG,verbose:b.VERBOSE,info:b.INFO,warn:b.WARN,error:b.ERROR,silent:b.SILENT},$r=b.INFO,Br={[b.DEBUG]:"log",[b.VERBOSE]:"log",[b.INFO]:"info",[b.WARN]:"warn",[b.ERROR]:"error"},jr=(n,t,...e)=>{if(t<n.logLevel)return;const r=new Date().toISOString(),s=Br[t];if(s)console[s](`[${r}]  ${n.name}:`,...e);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class Dn{constructor(t){this.name=t,this._logLevel=$r,this._logHandler=jr,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in b))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?Ur[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,b.DEBUG,...t),this._logHandler(this,b.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,b.VERBOSE,...t),this._logHandler(this,b.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,b.INFO,...t),this._logHandler(this,b.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,b.WARN,...t),this._logHandler(this,b.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,b.ERROR,...t),this._logHandler(this,b.ERROR,...t)}}const zr=(n,t)=>t.some(e=>n instanceof e);let Ge,He;function qr(){return Ge||(Ge=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Gr(){return He||(He=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Cn=new WeakMap,he=new WeakMap,On=new WeakMap,se=new WeakMap,we=new WeakMap;function Hr(n){const t=new Promise((e,r)=>{const s=()=>{n.removeEventListener("success",i),n.removeEventListener("error",a)},i=()=>{e(Y(n.result)),s()},a=()=>{r(n.error),s()};n.addEventListener("success",i),n.addEventListener("error",a)});return t.then(e=>{e instanceof IDBCursor&&Cn.set(e,n)}).catch(()=>{}),we.set(t,n),t}function Wr(n){if(he.has(n))return;const t=new Promise((e,r)=>{const s=()=>{n.removeEventListener("complete",i),n.removeEventListener("error",a),n.removeEventListener("abort",a)},i=()=>{e(),s()},a=()=>{r(n.error||new DOMException("AbortError","AbortError")),s()};n.addEventListener("complete",i),n.addEventListener("error",a),n.addEventListener("abort",a)});he.set(n,t)}let fe={get(n,t,e){if(n instanceof IDBTransaction){if(t==="done")return he.get(n);if(t==="objectStoreNames")return n.objectStoreNames||On.get(n);if(t==="store")return e.objectStoreNames[1]?void 0:e.objectStore(e.objectStoreNames[0])}return Y(n[t])},set(n,t,e){return n[t]=e,!0},has(n,t){return n instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in n}};function Kr(n){fe=n(fe)}function Jr(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...e){const r=n.call(ie(this),t,...e);return On.set(r,t.sort?t.sort():[t]),Y(r)}:Gr().includes(n)?function(...t){return n.apply(ie(this),t),Y(Cn.get(this))}:function(...t){return Y(n.apply(ie(this),t))}}function Qr(n){return typeof n=="function"?Jr(n):(n instanceof IDBTransaction&&Wr(n),zr(n,qr())?new Proxy(n,fe):n)}function Y(n){if(n instanceof IDBRequest)return Hr(n);if(se.has(n))return se.get(n);const t=Qr(n);return t!==n&&(se.set(n,t),we.set(t,n)),t}const ie=n=>we.get(n);function Yr(n,t,{blocked:e,upgrade:r,blocking:s,terminated:i}={}){const a=indexedDB.open(n,t),d=Y(a);return r&&a.addEventListener("upgradeneeded",m=>{r(Y(a.result),m.oldVersion,m.newVersion,Y(a.transaction),m)}),e&&a.addEventListener("blocked",m=>e(m.oldVersion,m.newVersion,m)),d.then(m=>{i&&m.addEventListener("close",()=>i()),s&&m.addEventListener("versionchange",g=>s(g.oldVersion,g.newVersion,g))}).catch(()=>{}),d}const Xr=["get","getKey","getAll","getAllKeys","count"],Zr=["put","add","delete","clear"],oe=new Map;function We(n,t){if(!(n instanceof IDBDatabase&&!(t in n)&&typeof t=="string"))return;if(oe.get(t))return oe.get(t);const e=t.replace(/FromIndex$/,""),r=t!==e,s=Zr.includes(e);if(!(e in(r?IDBIndex:IDBObjectStore).prototype)||!(s||Xr.includes(e)))return;const i=async function(a,...d){const m=this.transaction(a,s?"readwrite":"readonly");let g=m.store;return r&&(g=g.index(d.shift())),(await Promise.all([g[e](...d),s&&m.done]))[0]};return oe.set(t,i),i}Kr(n=>({...n,get:(t,e,r)=>We(t,e)||n.get(t,e,r),has:(t,e)=>!!We(t,e)||n.has(t,e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ts{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(e=>{if(es(e)){const r=e.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(e=>e).join(" ")}}function es(n){return n.getComponent()?.type==="VERSION"}const de="@firebase/app",Ke="0.16.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K=new Dn("@firebase/app"),ns="@firebase/app-compat",rs="@firebase/analytics-compat",ss="@firebase/analytics",is="@firebase/app-check-compat",os="@firebase/app-check",as="@firebase/auth",ls="@firebase/auth-compat",us="@firebase/database",cs="@firebase/data-connect",hs="@firebase/database-compat",fs="@firebase/functions",ds="@firebase/functions-compat",ps="@firebase/installations",ms="@firebase/installations-compat",gs="@firebase/messaging",_s="@firebase/messaging-compat",ys="@firebase/performance",Es="@firebase/performance-compat",Is="@firebase/remote-config",As="@firebase/remote-config-compat",ws="@firebase/storage",bs="@firebase/storage-compat",Ts="@firebase/firestore",vs="@firebase/ai",Vs="@firebase/firestore-compat",Ss="firebase",Ns="12.19.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pe="[DEFAULT]",Rs={[de]:"fire-core",[ns]:"fire-core-compat",[ss]:"fire-analytics",[rs]:"fire-analytics-compat",[os]:"fire-app-check",[is]:"fire-app-check-compat",[as]:"fire-auth",[ls]:"fire-auth-compat",[us]:"fire-rtdb",[cs]:"fire-data-connect",[hs]:"fire-rtdb-compat",[fs]:"fire-fn",[ds]:"fire-fn-compat",[ps]:"fire-iid",[ms]:"fire-iid-compat",[gs]:"fire-fcm",[_s]:"fire-fcm-compat",[ys]:"fire-perf",[Es]:"fire-perf-compat",[Is]:"fire-rc",[As]:"fire-rc-compat",[ws]:"fire-gcs",[bs]:"fire-gcs-compat",[Ts]:"fire-fst",[Vs]:"fire-fst-compat",[vs]:"fire-vertex","fire-js":"fire-js",[Ss]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yt=new Map,Ps=new Map,me=new Map;function Je(n,t){try{n.container.addComponent(t)}catch(e){K.debug(`Component ${t.name} failed to register with FirebaseApp ${n.name}`,e)}}function Ut(n){const t=n.name;if(me.has(t))return K.debug(`There were multiple attempts to register component ${t}.`),!1;me.set(t,n);for(const e of yt.values())Je(e,n);for(const e of Ps.values())Je(e,n);return!0}function Ds(n,t){const e=n.container.getProvider("heartbeat").getImmediate({optional:!0});return e&&e.triggerHeartbeat(),n.container.getProvider(t)}function Cs(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Os={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},G=new Rn("app","Firebase",Os);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ks{constructor(t,e,r){this._isDeleted=!1,this._options={...t},this._config={...e},this._name=e.name,this._automaticDataCollectionEnabled=e.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new _t("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw G.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fs=Ns;function Ms(n,t={}){let e=n;typeof t!="object"&&(t={name:t});const r={name:pe,automaticDataCollectionEnabled:!0,...t},s=r.name;if(typeof s!="string"||!s)throw G.create("bad-app-name",{appName:String(s)});if(e||(e=Sn()),!e)throw G.create("no-options");const i=yt.get(s);if(i)if(Lt(e,i.options)){if(Lt(r,i.config))return i;throw G.create("duplicate-app",{appName:s,mismatchedParam:"config",oldValue:JSON.stringify(i.config),newValue:JSON.stringify(r)})}else throw G.create("duplicate-app",{appName:s,mismatchedParam:"options",oldValue:JSON.stringify(i.options),newValue:JSON.stringify(e)});const a=new Lr(s);for(const m of me.values())a.addComponent(m);const d=new ks(e,r,a);return yt.set(s,d),d}function xs(n=pe){const t=yt.get(n);if(!t&&n===pe&&Sn())return Ms();if(!t)throw G.create("no-app",{appName:n});return t}function Ro(){return Array.from(yt.values())}function ut(n,t,e){let r=Rs[n]??n;e&&(r+=`-${e}`);const s=r.match(/\s|\//),i=t.match(/\s|\//);if(s||i){const a=[`Unable to register library "${r}" with version "${t}":`];s&&a.push(`library name "${r}" contains illegal characters (whitespace or "/")`),s&&i&&a.push("and"),i&&a.push(`version name "${t}" contains illegal characters (whitespace or "/")`),K.warn(a.join(" "));return}Ut(new _t(`${r}-version`,()=>({library:r,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ls="firebase-heartbeat-database",Us=1,Et="firebase-heartbeat-store";let ae=null;function kn(){return ae||(ae=Yr(Ls,Us,{upgrade:(n,t)=>{switch(t){case 0:try{n.createObjectStore(Et)}catch(e){console.warn(e)}}}}).catch(n=>{throw G.create("idb-open",{originalErrorMessage:n.message})})),ae}async function $s(n){try{const e=(await kn()).transaction(Et),r=await e.objectStore(Et).get(Fn(n));return await e.done,r}catch(t){if(t instanceof ft)K.warn(t.message);else{const e=G.create("idb-get",{originalErrorMessage:t?.message});K.warn(e.message)}}}async function Qe(n,t){try{const r=(await kn()).transaction(Et,"readwrite");await r.objectStore(Et).put(t,Fn(n)),await r.done}catch(e){if(e instanceof ft)K.warn(e.message);else{const r=G.create("idb-set",{originalErrorMessage:e?.message});K.warn(r.message)}}}function Fn(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bs=1024,js=30;class zs{constructor(t){this.container=t,this._heartbeatsCache=null;const e=this.container.getProvider("app").getImmediate();this._storage=new Gs(e),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){try{const e=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=Ye();if(this._heartbeatsCache?.heartbeats==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,this._heartbeatsCache?.heartbeats==null)||this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(s=>s.date===r))return;if(this._heartbeatsCache.heartbeats.push({date:r,agent:e}),this._heartbeatsCache.heartbeats.length>js){const s=Hs(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(s,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(t){K.warn(t)}}async getHeartbeatsHeader(){try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,this._heartbeatsCache?.heartbeats==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=Ye(),{heartbeatsToSend:e,unsentEntries:r}=qs(this._heartbeatsCache.heartbeats),s=xt(JSON.stringify({version:2,heartbeats:e}));return this._heartbeatsCache.lastSentHeartbeatDate=t,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),s}catch(t){return K.warn(t),""}}}function Ye(){return new Date().toISOString().substring(0,10)}function qs(n,t=Bs){const e=[];let r=n.slice();for(const s of n){const i=e.find(a=>a.agent===s.agent);if(i){if(i.dates.push(s.date),Xe(e)>t){i.dates.pop();break}}else if(e.push({agent:s.agent,dates:[s.date]}),Xe(e)>t){e.pop();break}r=r.slice(1)}return{heartbeatsToSend:e,unsentEntries:r}}class Gs{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Nr()?Rr().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const e=await $s(this.app);return e?.heartbeats?e:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return Qe(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return Qe(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...t.heartbeats]})}else return}}function Xe(n){return xt(JSON.stringify({version:2,heartbeats:n})).length}function Hs(n){if(n.length===0)return-1;let t=0,e=n[0].date;for(let r=1;r<n.length;r++)n[r].date<e&&(e=n[r].date,t=r);return t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ws(n){Ut(new _t("platform-logger",t=>new ts(t),"PRIVATE")),Ut(new _t("heartbeat",t=>new zs(t),"PRIVATE")),ut(de,Ke,n),ut(de,Ke,"esm2020"),ut("fire-js","")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ws("");var Ks="firebase",Js="12.19.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ut(Ks,Js,"app");var Ze=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Mn;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function t(c,o){function u(){}u.prototype=o.prototype,c.F=o.prototype,c.prototype=new u,c.prototype.constructor=c,c.D=function(f,h,p){for(var l=Array(arguments.length-2),et=2;et<arguments.length;et++)l[et-2]=arguments[et];return o.prototype[h].apply(f,l)}}function e(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}t(r,e),r.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function s(c,o,u){u||(u=0);const f=Array(16);if(typeof o=="string")for(var h=0;h<16;++h)f[h]=o.charCodeAt(u++)|o.charCodeAt(u++)<<8|o.charCodeAt(u++)<<16|o.charCodeAt(u++)<<24;else for(h=0;h<16;++h)f[h]=o[u++]|o[u++]<<8|o[u++]<<16|o[u++]<<24;o=c.g[0],u=c.g[1],h=c.g[2];let p=c.g[3],l;l=o+(p^u&(h^p))+f[0]+3614090360&4294967295,o=u+(l<<7&4294967295|l>>>25),l=p+(h^o&(u^h))+f[1]+3905402710&4294967295,p=o+(l<<12&4294967295|l>>>20),l=h+(u^p&(o^u))+f[2]+606105819&4294967295,h=p+(l<<17&4294967295|l>>>15),l=u+(o^h&(p^o))+f[3]+3250441966&4294967295,u=h+(l<<22&4294967295|l>>>10),l=o+(p^u&(h^p))+f[4]+4118548399&4294967295,o=u+(l<<7&4294967295|l>>>25),l=p+(h^o&(u^h))+f[5]+1200080426&4294967295,p=o+(l<<12&4294967295|l>>>20),l=h+(u^p&(o^u))+f[6]+2821735955&4294967295,h=p+(l<<17&4294967295|l>>>15),l=u+(o^h&(p^o))+f[7]+4249261313&4294967295,u=h+(l<<22&4294967295|l>>>10),l=o+(p^u&(h^p))+f[8]+1770035416&4294967295,o=u+(l<<7&4294967295|l>>>25),l=p+(h^o&(u^h))+f[9]+2336552879&4294967295,p=o+(l<<12&4294967295|l>>>20),l=h+(u^p&(o^u))+f[10]+4294925233&4294967295,h=p+(l<<17&4294967295|l>>>15),l=u+(o^h&(p^o))+f[11]+2304563134&4294967295,u=h+(l<<22&4294967295|l>>>10),l=o+(p^u&(h^p))+f[12]+1804603682&4294967295,o=u+(l<<7&4294967295|l>>>25),l=p+(h^o&(u^h))+f[13]+4254626195&4294967295,p=o+(l<<12&4294967295|l>>>20),l=h+(u^p&(o^u))+f[14]+2792965006&4294967295,h=p+(l<<17&4294967295|l>>>15),l=u+(o^h&(p^o))+f[15]+1236535329&4294967295,u=h+(l<<22&4294967295|l>>>10),l=o+(h^p&(u^h))+f[1]+4129170786&4294967295,o=u+(l<<5&4294967295|l>>>27),l=p+(u^h&(o^u))+f[6]+3225465664&4294967295,p=o+(l<<9&4294967295|l>>>23),l=h+(o^u&(p^o))+f[11]+643717713&4294967295,h=p+(l<<14&4294967295|l>>>18),l=u+(p^o&(h^p))+f[0]+3921069994&4294967295,u=h+(l<<20&4294967295|l>>>12),l=o+(h^p&(u^h))+f[5]+3593408605&4294967295,o=u+(l<<5&4294967295|l>>>27),l=p+(u^h&(o^u))+f[10]+38016083&4294967295,p=o+(l<<9&4294967295|l>>>23),l=h+(o^u&(p^o))+f[15]+3634488961&4294967295,h=p+(l<<14&4294967295|l>>>18),l=u+(p^o&(h^p))+f[4]+3889429448&4294967295,u=h+(l<<20&4294967295|l>>>12),l=o+(h^p&(u^h))+f[9]+568446438&4294967295,o=u+(l<<5&4294967295|l>>>27),l=p+(u^h&(o^u))+f[14]+3275163606&4294967295,p=o+(l<<9&4294967295|l>>>23),l=h+(o^u&(p^o))+f[3]+4107603335&4294967295,h=p+(l<<14&4294967295|l>>>18),l=u+(p^o&(h^p))+f[8]+1163531501&4294967295,u=h+(l<<20&4294967295|l>>>12),l=o+(h^p&(u^h))+f[13]+2850285829&4294967295,o=u+(l<<5&4294967295|l>>>27),l=p+(u^h&(o^u))+f[2]+4243563512&4294967295,p=o+(l<<9&4294967295|l>>>23),l=h+(o^u&(p^o))+f[7]+1735328473&4294967295,h=p+(l<<14&4294967295|l>>>18),l=u+(p^o&(h^p))+f[12]+2368359562&4294967295,u=h+(l<<20&4294967295|l>>>12),l=o+(u^h^p)+f[5]+4294588738&4294967295,o=u+(l<<4&4294967295|l>>>28),l=p+(o^u^h)+f[8]+2272392833&4294967295,p=o+(l<<11&4294967295|l>>>21),l=h+(p^o^u)+f[11]+1839030562&4294967295,h=p+(l<<16&4294967295|l>>>16),l=u+(h^p^o)+f[14]+4259657740&4294967295,u=h+(l<<23&4294967295|l>>>9),l=o+(u^h^p)+f[1]+2763975236&4294967295,o=u+(l<<4&4294967295|l>>>28),l=p+(o^u^h)+f[4]+1272893353&4294967295,p=o+(l<<11&4294967295|l>>>21),l=h+(p^o^u)+f[7]+4139469664&4294967295,h=p+(l<<16&4294967295|l>>>16),l=u+(h^p^o)+f[10]+3200236656&4294967295,u=h+(l<<23&4294967295|l>>>9),l=o+(u^h^p)+f[13]+681279174&4294967295,o=u+(l<<4&4294967295|l>>>28),l=p+(o^u^h)+f[0]+3936430074&4294967295,p=o+(l<<11&4294967295|l>>>21),l=h+(p^o^u)+f[3]+3572445317&4294967295,h=p+(l<<16&4294967295|l>>>16),l=u+(h^p^o)+f[6]+76029189&4294967295,u=h+(l<<23&4294967295|l>>>9),l=o+(u^h^p)+f[9]+3654602809&4294967295,o=u+(l<<4&4294967295|l>>>28),l=p+(o^u^h)+f[12]+3873151461&4294967295,p=o+(l<<11&4294967295|l>>>21),l=h+(p^o^u)+f[15]+530742520&4294967295,h=p+(l<<16&4294967295|l>>>16),l=u+(h^p^o)+f[2]+3299628645&4294967295,u=h+(l<<23&4294967295|l>>>9),l=o+(h^(u|~p))+f[0]+4096336452&4294967295,o=u+(l<<6&4294967295|l>>>26),l=p+(u^(o|~h))+f[7]+1126891415&4294967295,p=o+(l<<10&4294967295|l>>>22),l=h+(o^(p|~u))+f[14]+2878612391&4294967295,h=p+(l<<15&4294967295|l>>>17),l=u+(p^(h|~o))+f[5]+4237533241&4294967295,u=h+(l<<21&4294967295|l>>>11),l=o+(h^(u|~p))+f[12]+1700485571&4294967295,o=u+(l<<6&4294967295|l>>>26),l=p+(u^(o|~h))+f[3]+2399980690&4294967295,p=o+(l<<10&4294967295|l>>>22),l=h+(o^(p|~u))+f[10]+4293915773&4294967295,h=p+(l<<15&4294967295|l>>>17),l=u+(p^(h|~o))+f[1]+2240044497&4294967295,u=h+(l<<21&4294967295|l>>>11),l=o+(h^(u|~p))+f[8]+1873313359&4294967295,o=u+(l<<6&4294967295|l>>>26),l=p+(u^(o|~h))+f[15]+4264355552&4294967295,p=o+(l<<10&4294967295|l>>>22),l=h+(o^(p|~u))+f[6]+2734768916&4294967295,h=p+(l<<15&4294967295|l>>>17),l=u+(p^(h|~o))+f[13]+1309151649&4294967295,u=h+(l<<21&4294967295|l>>>11),l=o+(h^(u|~p))+f[4]+4149444226&4294967295,o=u+(l<<6&4294967295|l>>>26),l=p+(u^(o|~h))+f[11]+3174756917&4294967295,p=o+(l<<10&4294967295|l>>>22),l=h+(o^(p|~u))+f[2]+718787259&4294967295,h=p+(l<<15&4294967295|l>>>17),l=u+(p^(h|~o))+f[9]+3951481745&4294967295,c.g[0]=c.g[0]+o&4294967295,c.g[1]=c.g[1]+(h+(l<<21&4294967295|l>>>11))&4294967295,c.g[2]=c.g[2]+h&4294967295,c.g[3]=c.g[3]+p&4294967295}r.prototype.v=function(c,o){o===void 0&&(o=c.length);const u=o-this.blockSize,f=this.C;let h=this.h,p=0;for(;p<o;){if(h==0)for(;p<=u;)s(this,c,p),p+=this.blockSize;if(typeof c=="string"){for(;p<o;)if(f[h++]=c.charCodeAt(p++),h==this.blockSize){s(this,f),h=0;break}}else for(;p<o;)if(f[h++]=c[p++],h==this.blockSize){s(this,f),h=0;break}}this.h=h,this.o+=o},r.prototype.A=function(){var c=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);c[0]=128;for(var o=1;o<c.length-8;++o)c[o]=0;o=this.o*8;for(var u=c.length-8;u<c.length;++u)c[u]=o&255,o/=256;for(this.v(c),c=Array(16),o=0,u=0;u<4;++u)for(let f=0;f<32;f+=8)c[o++]=this.g[u]>>>f&255;return c};function i(c,o){var u=d;return Object.prototype.hasOwnProperty.call(u,c)?u[c]:u[c]=o(c)}function a(c,o){this.h=o;const u=[];let f=!0;for(let h=c.length-1;h>=0;h--){const p=c[h]|0;f&&p==o||(u[h]=p,f=!1)}this.g=u}var d={};function m(c){return-128<=c&&c<128?i(c,function(o){return new a([o|0],o<0?-1:0)}):new a([c|0],c<0?-1:0)}function g(c){if(isNaN(c)||!isFinite(c))return I;if(c<0)return N(g(-c));const o=[];let u=1;for(let f=0;c>=u;f++)o[f]=c/u|0,u*=4294967296;return new a(o,0)}function y(c,o){if(c.length==0)throw Error("number format error: empty string");if(o=o||10,o<2||36<o)throw Error("radix out of range: "+o);if(c.charAt(0)=="-")return N(y(c.substring(1),o));if(c.indexOf("-")>=0)throw Error('number format error: interior "-" character');const u=g(Math.pow(o,8));let f=I;for(let p=0;p<c.length;p+=8){var h=Math.min(8,c.length-p);const l=parseInt(c.substring(p,p+h),o);h<8?(h=g(Math.pow(o,h)),f=f.j(h).add(g(l))):(f=f.j(u),f=f.add(g(l)))}return f}var I=m(0),A=m(1),S=m(16777216);n=a.prototype,n.m=function(){if(F(this))return-N(this).m();let c=0,o=1;for(let u=0;u<this.g.length;u++){const f=this.i(u);c+=(f>=0?f:4294967296+f)*o,o*=4294967296}return c},n.toString=function(c){if(c=c||10,c<2||36<c)throw Error("radix out of range: "+c);if(v(this))return"0";if(F(this))return"-"+N(this).toString(c);const o=g(Math.pow(c,6));var u=this;let f="";for(;;){const h=Ct(u,o).g;u=Pt(u,h.j(o));let p=((u.g.length>0?u.g[0]:u.h)>>>0).toString(c);if(u=h,v(u))return p+f;for(;p.length<6;)p="0"+p;f=p+f}},n.i=function(c){return c<0?0:c<this.g.length?this.g[c]:this.h};function v(c){if(c.h!=0)return!1;for(let o=0;o<c.g.length;o++)if(c.g[o]!=0)return!1;return!0}function F(c){return c.h==-1}n.l=function(c){return c=Pt(this,c),F(c)?-1:v(c)?0:1};function N(c){const o=c.g.length,u=[];for(let f=0;f<o;f++)u[f]=~c.g[f];return new a(u,~c.h).add(A)}n.abs=function(){return F(this)?N(this):this},n.add=function(c){const o=Math.max(this.g.length,c.g.length),u=[];let f=0;for(let h=0;h<=o;h++){let p=f+(this.i(h)&65535)+(c.i(h)&65535),l=(p>>>16)+(this.i(h)>>>16)+(c.i(h)>>>16);f=l>>>16,p&=65535,l&=65535,u[h]=l<<16|p}return new a(u,u[u.length-1]&-2147483648?-1:0)};function Pt(c,o){return c.add(N(o))}n.j=function(c){if(v(this)||v(c))return I;if(F(this))return F(c)?N(this).j(N(c)):N(N(this).j(c));if(F(c))return N(this.j(N(c)));if(this.l(S)<0&&c.l(S)<0)return g(this.m()*c.m());const o=this.g.length+c.g.length,u=[];for(var f=0;f<2*o;f++)u[f]=0;for(f=0;f<this.g.length;f++)for(let h=0;h<c.g.length;h++){const p=this.i(f)>>>16,l=this.i(f)&65535,et=c.i(h)>>>16,je=c.i(h)&65535;u[2*f+2*h]+=l*je,Dt(u,2*f+2*h),u[2*f+2*h+1]+=p*je,Dt(u,2*f+2*h+1),u[2*f+2*h+1]+=l*et,Dt(u,2*f+2*h+1),u[2*f+2*h+2]+=p*et,Dt(u,2*f+2*h+2)}for(c=0;c<o;c++)u[c]=u[2*c+1]<<16|u[2*c];for(c=o;c<2*o;c++)u[c]=0;return new a(u,0)};function Dt(c,o){for(;(c[o]&65535)!=c[o];)c[o+1]+=c[o]>>>16,c[o]&=65535,o++}function pt(c,o){this.g=c,this.h=o}function Ct(c,o){if(v(o))throw Error("division by zero");if(v(c))return new pt(I,I);if(F(c))return o=Ct(N(c),o),new pt(N(o.g),N(o.h));if(F(o))return o=Ct(c,N(o)),new pt(N(o.g),o.h);if(c.g.length>30){if(F(c)||F(o))throw Error("slowDivide_ only works with positive integers.");for(var u=A,f=o;f.l(c)<=0;)u=Be(u),f=Be(f);var h=ot(u,1),p=ot(f,1);for(f=ot(f,2),u=ot(u,2);!v(f);){var l=p.add(f);l.l(c)<=0&&(h=h.add(u),p=l),f=ot(f,1),u=ot(u,1)}return o=Pt(c,h.j(o)),new pt(h,o)}for(h=I;c.l(o)>=0;){for(u=Math.max(1,Math.floor(c.m()/o.m())),f=Math.ceil(Math.log(u)/Math.LN2),f=f<=48?1:Math.pow(2,f-48),p=g(u),l=p.j(o);F(l)||l.l(c)>0;)u-=f,p=g(u),l=p.j(o);v(p)&&(p=A),h=h.add(p),c=Pt(c,l)}return new pt(h,c)}n.B=function(c){return Ct(this,c).h},n.and=function(c){const o=Math.max(this.g.length,c.g.length),u=[];for(let f=0;f<o;f++)u[f]=this.i(f)&c.i(f);return new a(u,this.h&c.h)},n.or=function(c){const o=Math.max(this.g.length,c.g.length),u=[];for(let f=0;f<o;f++)u[f]=this.i(f)|c.i(f);return new a(u,this.h|c.h)},n.xor=function(c){const o=Math.max(this.g.length,c.g.length),u=[];for(let f=0;f<o;f++)u[f]=this.i(f)^c.i(f);return new a(u,this.h^c.h)};function Be(c){const o=c.g.length+1,u=[];for(let f=0;f<o;f++)u[f]=c.i(f)<<1|c.i(f-1)>>>31;return new a(u,c.h)}function ot(c,o){const u=o>>5;o%=32;const f=c.g.length-u,h=[];for(let p=0;p<f;p++)h[p]=o>0?c.i(p+u)>>>o|c.i(p+u+1)<<32-o:c.i(p+u);return new a(h,c.h)}r.prototype.digest=r.prototype.A,r.prototype.reset=r.prototype.u,r.prototype.update=r.prototype.v,a.prototype.add=a.prototype.add,a.prototype.multiply=a.prototype.j,a.prototype.modulo=a.prototype.B,a.prototype.compare=a.prototype.l,a.prototype.toNumber=a.prototype.m,a.prototype.toString=a.prototype.toString,a.prototype.getBits=a.prototype.i,a.fromNumber=g,a.fromString=y,Mn=a}).apply(typeof Ze<"u"?Ze:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class x{constructor(t){this.uid=t}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(t){return t.uid===this.uid}}x.UNAUTHENTICATED=new x(null),x.GOOGLE_CREDENTIALS=new x("google-credentials-uid"),x.FIRST_PARTY=new x("first-party-uid"),x.MOCK_USER=new x("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let dt="12.19.0";function Qs(n){dt=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ht=new Dn("@firebase/firestore");function $t(n,...t){if(ht.logLevel<=b.DEBUG){const e=t.map(Te);ht.debug(`Firestore (${dt}): ${n}`,...e)}}function be(n,...t){if(ht.logLevel<=b.ERROR){const e=t.map(Te);ht.error(`Firestore (${dt}): ${n}`,...e)}}function xn(n,...t){if(ht.logLevel<=b.WARN){const e=t.map(Te);ht.warn(`Firestore (${dt}): ${n}`,...e)}}function Te(n){if(typeof n=="string")return n;try{return(function(e){return JSON.stringify(e)})(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function V(n,t,e){let r="Unexpected state";typeof t=="string"?r=t:e=t,Ln(n,r,e)}function Ln(n,t,e){let r=`FIRESTORE (${dt}) INTERNAL ASSERTION FAILED: ${t} (ID: ${n.toString(16)})`;if(e!==void 0)try{r+=" CONTEXT: "+JSON.stringify(e)}catch{r+=" CONTEXT: "+e}throw be(r),new Error(r)}function Z(n,t,e,r){let s="Unexpected state";typeof e=="string"?s=e:r=e,n||Ln(t,s,r)}function Kt(n,t){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable"};class E extends ft{constructor(t,e){super(t,e),this.code=t,this.message=e,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Un{constructor(t,e){this.user=e,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${t}`)}}class Ys{getToken(){return Promise.resolve(null)}invalidateToken(){}start(t,e){t.enqueueRetryable((()=>e(x.UNAUTHENTICATED)))}shutdown(){}}class Xs{constructor(t){this.token=t,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(t,e){this.changeListener=e,t.enqueueRetryable((()=>e(this.token.user)))}shutdown(){this.changeListener=null}}class Zs{constructor(t){this.auth=null,t.onInit((e=>{this.auth=e}))}getToken(){return this.auth?this.auth.getToken().then((t=>t?(Z(typeof t.accessToken=="string",42297,{Z:t}),new Un(t.accessToken,new x(this.auth.getUid()))):null)):Promise.resolve(null)}invalidateToken(){}start(t,e){}shutdown(){}}class ti{constructor(t,e,r){this.ee=t,this.te=e,this.re=r,this.type="FirstParty",this.user=x.FIRST_PARTY,this.ne=new Map}ie(){return this.re?this.re():null}get headers(){this.ne.set("X-Goog-AuthUser",this.ee);const t=this.ie();return t&&this.ne.set("Authorization",t),this.te&&this.ne.set("X-Goog-Iam-Authorization-Token",this.te),this.ne}}class ei{constructor(t,e,r){this.ee=t,this.te=e,this.re=r}getToken(){return Promise.resolve(new ti(this.ee,this.te,this.re))}start(t,e){t.enqueueRetryable((()=>e(x.FIRST_PARTY)))}shutdown(){}invalidateToken(){}}class tn{constructor(t){this.value=t,this.type="AppCheck",this.headers=new Map,t&&t.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class ni{constructor(t,e){this.se=e,this.appCheck=null,this.oe=null,Cs(t)&&t.settings.appCheckToken&&(this.oe=t.settings.appCheckToken),e.onInit((r=>{this.appCheck=r}))}getToken(){return this.oe?Promise.resolve(new tn(this.oe)):this.appCheck?this.appCheck.getToken().then((t=>t?(Z(typeof t.token=="string",3470,{tokenResult:t}),new tn(t.token)):null)):Promise.resolve(null)}invalidateToken(){}start(t,e){}shutdown(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ri{constructor(t,e,r,s,i,a,d,m,g,y,I,A,S){this.databaseId=t,this.appId=e,this.persistenceKey=r,this.host=s,this.ssl=i,this.forceLongPolling=a,this.autoDetectLongPolling=d,this.longPollingOptions=m,this.useFetchStreams=g,this.isUsingEmulator=y,this.apiKey=I,this._customHeaders=A,this.grpcFlowControlWindow=S}}const ge="(default)";class It{constructor(t,e){this.projectId=t,this.database=e||ge}static empty(){return new It("","")}get isDefaultDatabase(){return this.database===ge}isEqual(t){return t instanceof It&&t.projectId===this.projectId&&t.database===this.database}}function si(n,t){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new E(_.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new It(n.options.projectId,t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ii(n){const t=typeof self<"u"&&(self.crypto||self.msCrypto),e=new Uint8Array(n);if(t&&typeof t.getRandomValues=="function")t.getRandomValues(e);else for(let r=0;r<n;r++)e[r]=Math.floor(256*Math.random());return e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oi{static newId(){const t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",e=62*Math.floor(4.129032258064516);let r="";for(;r.length<20;){const s=ii(40);for(let i=0;i<s.length;++i)r.length<20&&s[i]<e&&(r+=t.charAt(s[i]%62))}return r}}function R(n,t){return n<t?-1:n>t?1:0}function _e(n,t){const e=Math.min(n.length,t.length);for(let r=0;r<e;r++){const s=n.charAt(r),i=t.charAt(r);if(s!==i)return le(s)===le(i)?R(s,i):le(s)?1:-1}return R(n.length,t.length)}const ai=55296,li=57343;function le(n){const t=n.charCodeAt(0);return t>=ai&&t<=li}function $n(n,t,e){return n.length===t.length&&n.every(((r,s)=>e(r,t[s])))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const en="__name__";class z{constructor(t,e,r){e===void 0?e=0:e>t.length&&V(637,{offset:e,range:t.length}),r===void 0?r=t.length-e:r>t.length-e&&V(1746,{length:r,range:t.length-e}),this.segments=t,this.offset=e,this.len=r}get length(){return this.len}isEqual(t){return z.comparator(this,t)===0}child(t){const e=this.segments.slice(this.offset,this.limit());return t instanceof z?t.forEach((r=>{e.push(r)})):e.push(t),this.construct(e)}limit(){return this.offset+this.length}popFirst(t){return t=t===void 0?1:t,this.construct(this.segments,this.offset+t,this.length-t)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(t){return this.segments[this.offset+t]}isEmpty(){return this.length===0}isPrefixOf(t){if(t.length<this.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}isImmediateParentOf(t){if(this.length+1!==t.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}forEach(t){for(let e=this.offset,r=this.limit();e<r;e++)t(this.segments[e])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(t,e){const r=Math.min(t.length,e.length);for(let s=0;s<r;s++){const i=z.compareSegments(t.get(s),e.get(s));if(i!==0)return i}return R(t.length,e.length)}static compareSegments(t,e){const r=z.isNumericId(t),s=z.isNumericId(e);return r&&!s?-1:!r&&s?1:r&&s?z.extractNumericId(t).compare(z.extractNumericId(e)):_e(t,e)}static isNumericId(t){return t.startsWith("__id")&&t.endsWith("__")}static extractNumericId(t){return Mn.fromString(t.substring(4,t.length-2))}}class D extends z{construct(t,e,r){return new D(t,e,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toStringWithLeadingSlash(){return`/${this.canonicalString()}`}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...t){const e=[];for(const r of t){if(r.indexOf("//")>=0)throw new E(_.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);e.push(...r.split("/").filter((s=>s.length>0)))}return new D(e)}static emptyPath(){return new D([])}}const ui=/^[_a-zA-Z][_a-zA-Z0-9]*$/;let X=class at extends z{construct(t,e,r){return new at(t,e,r)}static isValidIdentifier(t){return ui.test(t)}canonicalString(){return this.toArray().map((t=>(t=t.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),at.isValidIdentifier(t)||(t="`"+t+"`"),t))).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===en}static keyField(){return new at([en])}static fromServerFormat(t){const e=[];let r="",s=0;const i=()=>{if(r.length===0)throw new E(_.INVALID_ARGUMENT,`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);e.push(r),r=""};let a=!1;for(;s<t.length;){const d=t[s];if(d==="\\"){if(s+1===t.length)throw new E(_.INVALID_ARGUMENT,"Path has trailing escape character: "+t);const m=t[s+1];if(m!=="\\"&&m!=="."&&m!=="`")throw new E(_.INVALID_ARGUMENT,"Path has invalid escape sequence: "+t);r+=m,s+=2}else d==="`"?(a=!a,s++):d!=="."||a?(r+=d,s++):(i(),s++)}if(i(),a)throw new E(_.INVALID_ARGUMENT,"Unterminated ` in path: "+t);return new at(e)}static emptyPath(){return new at([])}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class O{constructor(t){this.path=t}static fromPath(t){return new O(D.fromString(t))}static fromName(t){return new O(D.fromString(t).popFirst(5))}static empty(){return new O(D.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(t){return this.path.length>=2&&this.path.get(this.path.length-2)===t}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(t){return t!==null&&D.comparator(this.path,t.path)===0}toString(){return this.path.toString()}static comparator(t,e){return D.comparator(t.path,e.path)}static isDocumentKey(t){return t.length%2==0}static fromSegments(t){return new O(new D(t.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bn(n,t,e){if(!e)throw new E(_.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${t}.`)}function nn(n){if(!O.isDocumentKey(n))throw new E(_.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function rn(n){if(O.isDocumentKey(n))throw new E(_.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function jn(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function Jt(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const t=(function(r){return r.constructor?r.constructor.name:null})(n);return t?`a custom ${t} object`:"an object"}}return typeof n=="function"?"a function":V(12329,{type:typeof n})}function Qt(n,t){if("_delegate"in n&&(n=n._delegate),!(n instanceof t)){if(t.name===n.constructor.name)throw new E(_.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const e=Jt(n);throw new E(_.INVALID_ARGUMENT,`Expected type '${t.name}', but it was: ${e}`)}}return n}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zn(n){const t={};return n.timeoutSeconds!==void 0&&(t.timeoutSeconds=n.timeoutSeconds),t}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ot=null;function ci(){return Ot===null?Ot=(function(){return 268435456+Math.round(2147483648*Math.random())})():Ot++,"0x"+Ot.toString(16)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hi(n){return n==null}function Bt(n){return n===0&&1/n==-1/0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ue="RestConnection",fi={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class di{get ae(){return!1}constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const e=t.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),s=encodeURIComponent(this.databaseId.database);this.ue=e+"://"+t.host,this._e=`projects/${r}/databases/${s}`,this.ce=this.databaseId.database===ge?`project_id=${r}`:`project_id=${r}&database_id=${s}`}le(t,e,r,s,i){const a=ci(),d=this.he(t,e.toUriEncodedString());$t(ue,`Sending RPC '${t}' ${a}:`,d,r);const m={"google-cloud-resource-prefix":this._e,"x-goog-request-params":this.ce};this.fe(m,s,i);const{host:g}=new URL(d),y=Pn(g);return this.me(t,d,m,r,y).then((I=>($t(ue,`Received RPC '${t}' ${a}: `,I),I)),(I=>{throw xn(ue,`RPC '${t}' ${a} failed with error: `,I,"url: ",d,"request:",r),I}))}de(t,e,r,s,i,a){return this.le(t,e,r,s,i)}fe(t,e,r){if(t["X-Goog-Api-Client"]=(function(){return"gl-js/ fire/"+dt})(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),e&&e.headers.forEach(((s,i)=>t[i]=s)),r&&r.headers.forEach(((s,i)=>t[i]=s)),this.databaseInfo._customHeaders)for(const s of Object.keys(this.databaseInfo._customHeaders))t[s]=this.databaseInfo._customHeaders[s]}he(t,e){const r=fi[t];let s=`${this.ue}/v1/${e}:${r}`;return this.databaseInfo.apiKey&&(s=`${s}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),s}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var sn,w;function on(n){if(n===void 0)return be("RPC_ERROR","HTTP error has no status"),_.UNKNOWN;switch(n){case 200:return _.OK;case 400:return _.FAILED_PRECONDITION;case 401:return _.UNAUTHENTICATED;case 403:return _.PERMISSION_DENIED;case 404:return _.NOT_FOUND;case 409:return _.ABORTED;case 416:return _.OUT_OF_RANGE;case 429:return _.RESOURCE_EXHAUSTED;case 499:return _.CANCELLED;case 500:return _.UNKNOWN;case 501:return _.UNIMPLEMENTED;case 503:return _.UNAVAILABLE;case 504:return _.DEADLINE_EXCEEDED;default:return n>=200&&n<300?_.OK:n>=400&&n<500?_.FAILED_PRECONDITION:n>=500&&n<600?_.INTERNAL:_.UNKNOWN}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(w=sn||(sn={}))[w.OK=0]="OK",w[w.CANCELLED=1]="CANCELLED",w[w.UNKNOWN=2]="UNKNOWN",w[w.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",w[w.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",w[w.NOT_FOUND=5]="NOT_FOUND",w[w.ALREADY_EXISTS=6]="ALREADY_EXISTS",w[w.PERMISSION_DENIED=7]="PERMISSION_DENIED",w[w.UNAUTHENTICATED=16]="UNAUTHENTICATED",w[w.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",w[w.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",w[w.ABORTED=10]="ABORTED",w[w.OUT_OF_RANGE=11]="OUT_OF_RANGE",w[w.UNIMPLEMENTED=12]="UNIMPLEMENTED",w[w.INTERNAL=13]="INTERNAL",w[w.UNAVAILABLE=14]="UNAVAILABLE",w[w.DATA_LOSS=15]="DATA_LOSS";class pi extends di{Ee(t,e){throw new Error("Not supported by FetchConnection")}async me(t,e,r,s,i){const a=JSON.stringify(s);let d;try{const m={method:"POST",headers:r,body:a};i&&(m.credentials="include"),d=await fetch(e,m)}catch(m){const g=m,y=g?.message,I=g?.cause?String(g.cause):void 0,A=(y&&I?`${y} (${I})`:y??I)??g?.statusText??String(m);throw new E(on(g?.status),`Request failed with error: ${A}`)}if(!d.ok){let m=await d.json();Array.isArray(m)&&(m=m[0]);const g=m?.error?.message;throw new E(on(d.status),`Request failed with error: ${g??d.statusText}`)}return d.json()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function an(n){let t=0;for(const e in n)Object.prototype.hasOwnProperty.call(n,e)&&t++;return t}function Vt(n,t){for(const e in n)Object.prototype.hasOwnProperty.call(n,e)&&t(e,n[e])}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mi extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class J{constructor(t){this.binaryString=t}static fromBase64String(t){const e=(function(s){try{return atob(s)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new mi("Invalid base64 string: "+i):i}})(t);return new J(e)}static fromUint8Array(t){const e=(function(s){let i="";for(let a=0;a<s.length;++a)i+=String.fromCharCode(s[a]);return i})(t);return new J(e)}[Symbol.iterator](){let t=0;return{next:()=>t<this.binaryString.length?{value:this.binaryString.charCodeAt(t++),done:!1}:{value:void 0,done:!0}}}toBase64(){return(function(e){return btoa(e)})(this.binaryString)}toUint8Array(){return(function(e){const r=new Uint8Array(e.length);for(let s=0;s<e.length;s++)r[s]=e.charCodeAt(s);return r})(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(t){return R(this.binaryString,t.binaryString)}isEqual(t){return this.binaryString===t.binaryString}}J.EMPTY_BYTE_STRING=new J("");const gi=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function rt(n){if(Z(!!n,39018),typeof n=="string"){let t=0;const e=gi.exec(n);if(Z(!!e,46558,{timestamp:n}),e[1]){let s=e[1];s=(s+"000000000").substr(0,9),t=Number(s)}const r=new Date(n);return{seconds:Math.floor(r.getTime()/1e3),nanos:t}}return{seconds:P(n.seconds),nanos:P(n.nanos)}}function P(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function At(n){return typeof n=="string"?J.fromBase64String(n):J.fromUint8Array(n)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $(n,t){const e={typeString:n};return t&&(e.value=t),e}function St(n,t){if(!jn(n))throw new E(_.INVALID_ARGUMENT,"JSON must be an object");let e;for(const r in t)if(t[r]){const s=t[r].typeString,i="value"in t[r]?{value:t[r].value}:void 0;if(!(r in n)){e=`JSON missing required field: '${r}'`;break}const a=n[r];if(s&&typeof a!==s){e=`JSON field '${r}' must be a ${s}.`;break}if(i!==void 0&&a!==i.value){e=`Expected '${r}' field to equal '${i.value}'`;break}}if(e)throw new E(_.INVALID_ARGUMENT,e);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ln=-62135596800,un=1e6;class T{static now(){return T.fromMillis(Date.now())}static fromDate(t){return T.fromMillis(t.getTime())}static fromMillis(t){const e=Math.floor(t/1e3),r=Math.floor((t-1e3*e)*un);return new T(e,r)}static fromInstant(t){if(!t||typeof t.Te!="bigint")throw new E(_.INVALID_ARGUMENT,"Invalid Temporal.Instant object provided.");return T._fromEpochNanoseconds(t.Te)}static _fromEpochNanoseconds(t){let e,r;if(t>=0n)e=Number(t/1000000000n),r=Number(t%1000000000n);else{const s=t%1000000000n;s===0n?(e=Number(t/1000000000n),r=0):(e=Number(t/1000000000n-1n),r=Number(s+1000000000n))}return new T(e,r)}constructor(t,e){if(this.seconds=t,this.nanoseconds=e,e<0)throw new E(_.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(e>=1e9)throw new E(_.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(t<ln)throw new E(_.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t);if(t>=253402300800)throw new E(_.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/un}toInstant(){if(typeof Temporal>"u"||!Temporal.Instant)throw new E(_.FAILED_PRECONDITION,"The Temporal object is not available in the current environment.");const t=1000000000n*BigInt(this.seconds)+BigInt(this.nanoseconds);return Temporal.Instant.__PRIVATE_fromEpochNanoseconds(t)}_compareTo(t){return this.seconds===t.seconds?R(this.nanoseconds,t.nanoseconds):R(this.seconds,t.seconds)}isEqual(t){return t.seconds===this.seconds&&t.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:T._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(t){if(St(t,T._jsonSchema))return new T(t.seconds,t.nanoseconds)}valueOf(){const t=this.seconds-ln;return String(t).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}T._jsonSchemaVersion="firestore/timestamp/1.0",T._jsonSchema={type:$("string",T._jsonSchemaVersion),seconds:$("number"),nanoseconds:$("number")};function qn(n){return(n?.mapValue?.fields||{}).__type__?.stringValue==="server_timestamp"}function Gn(n){const t=n.mapValue.fields.__previous_value__;return qn(t)?Gn(t):t}function wt(n){const t=rt(n.mapValue.fields.__local_write_time__.timestampValue);return new T(t.seconds,t.nanos)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hn="__type__",_i="__max__",kt={},Wn="__vector__",jt="value";function st(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?qn(n)?4:(function(e){return(((e.mapValue||{}).fields||{}).__type__||{}).stringValue===_i})(n)?9007199254740991:(function(e){return(e?.mapValue?.fields||{})[Hn]?.stringValue===Wn})(n)?10:11:V(28295,{value:n})}function zt(n,t,e){if(n===t)return!0;const r=st(n);if(r!==st(t))return!1;switch(r){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===t.booleanValue;case 4:return wt(n).isEqual(wt(t));case 3:return(function(i,a){if(typeof i.timestampValue=="string"&&typeof a.timestampValue=="string"&&i.timestampValue.length===a.timestampValue.length)return i.timestampValue===a.timestampValue;const d=rt(i.timestampValue),m=rt(a.timestampValue);return d.seconds===m.seconds&&d.nanos===m.nanos})(n,t);case 5:return n.stringValue===t.stringValue;case 6:return(function(i,a){return At(i.bytesValue).isEqual(At(a.bytesValue))})(n,t);case 7:return n.referenceValue===t.referenceValue;case 8:return(function(i,a){return P(i.geoPointValue.latitude)===P(a.geoPointValue.latitude)&&P(i.geoPointValue.longitude)===P(a.geoPointValue.longitude)})(n,t);case 2:return(function(i,a,d){if("integerValue"in i&&"integerValue"in a)return P(i.integerValue)===P(a.integerValue);let m,g;return!("doubleValue"in i)||!("doubleValue"in a)?!1:(m=P(i.doubleValue),g=P(a.doubleValue),m===g?Bt(m)===Bt(g):!!(d===void 0||d.Pe)&&isNaN(m)&&isNaN(g))})(n,t,e);case 9:return $n(n.arrayValue.values||[],t.arrayValue.values||[],((s,i)=>zt(s,i,e)));case 10:case 11:return(function(i,a,d){const m=i.mapValue.fields||{},g=a.mapValue.fields||{};if(an(m)!==an(g))return!1;for(const y in m)if(m.hasOwnProperty(y)&&(g[y]===void 0||!zt(m[y],g[y],d)))return!1;return!0})(n,t,e);default:return V(52216,{left:n})}}function bt(n,t){return(n.values||[]).find((e=>zt(e,t)))!==void 0}function qt(n,t){if(n===t)return 0;const e=st(n),r=st(t);if(e!==r)return R(e,r);switch(e){case 0:case 9007199254740991:return 0;case 1:return R(n.booleanValue,t.booleanValue);case 2:return(function(i,a){const d=P(i.integerValue||i.doubleValue),m=P(a.integerValue||a.doubleValue);return d<m?-1:d>m?1:d===m?0:isNaN(d)?isNaN(m)?0:-1:1})(n,t);case 3:return cn(n.timestampValue,t.timestampValue);case 4:return cn(wt(n),wt(t));case 5:return _e(n.stringValue,t.stringValue);case 6:return(function(i,a){const d=At(i),m=At(a);return d.compareTo(m)})(n.bytesValue,t.bytesValue);case 7:return(function(i,a){const d=i.split("/"),m=a.split("/");for(let g=0;g<d.length&&g<m.length;g++){const y=R(d[g],m[g]);if(y!==0)return y}return R(d.length,m.length)})(n.referenceValue,t.referenceValue);case 8:return(function(i,a){const d=R(P(i.latitude),P(a.latitude));return d!==0?d:R(P(i.longitude),P(a.longitude))})(n.geoPointValue,t.geoPointValue);case 9:return hn(n.arrayValue,t.arrayValue);case 10:return(function(i,a){const d=i.fields||{},m=a.fields||{},g=d[jt]?.arrayValue,y=m[jt]?.arrayValue,I=R(g?.values?.length||0,y?.values?.length||0);return I!==0?I:hn(g,y)})(n.mapValue,t.mapValue);case 11:return(function(i,a){if(i===kt&&a===kt)return 0;if(i===kt)return 1;if(a===kt)return-1;const d=i.fields||{},m=Object.keys(d),g=a.fields||{},y=Object.keys(g);m.sort(),y.sort();for(let I=0;I<m.length&&I<y.length;++I){const A=_e(m[I],y[I]);if(A!==0)return A;const S=qt(d[m[I]],g[y[I]]);if(S!==0)return S}return R(m.length,y.length)})(n.mapValue,t.mapValue);default:throw V(23264,{Re:e})}}function cn(n,t){if(typeof n=="string"&&typeof t=="string"&&n.length===t.length)return R(n,t);const e=rt(n),r=rt(t),s=R(e.seconds,r.seconds);return s!==0?s:R(e.nanos,r.nanos)}function hn(n,t){const e=n.values||[],r=t.values||[];for(let s=0;s<e.length&&s<r.length;++s){const i=qt(e[s],r[s]);if(i!==void 0&&i!==0)return i}return R(e.length,r.length)}function fn(n,t){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${t.path.canonicalString()}`}}function Kn(n){return!!n&&"arrayValue"in n}function dn(n){return!!n&&"nullValue"in n}function pn(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function ce(n){return!!n&&"mapValue"in n}function mt(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const t={mapValue:{fields:{}}};return Vt(n.mapValue.fields,((e,r)=>t.mapValue.fields[e]=mt(r))),t}if(n.arrayValue){const t={arrayValue:{values:[]}};for(let e=0;e<(n.arrayValue.values||[]).length;++e)t.arrayValue.values[e]=mt(n.arrayValue.values[e]);return t}return{...n}}class mn{constructor(t,e){this.position=t,this.inclusive=e}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jn{}class j extends Jn{constructor(t,e,r){super(),this.field=t,this.op=e,this.value=r}static create(t,e,r){return t.isKeyField()?e==="in"||e==="not-in"?this.createKeyFieldInFilter(t,e,r):new yi(t,e,r):e==="array-contains"?new Ai(t,r):e==="in"?new wi(t,r):e==="not-in"?new bi(t,r):e==="array-contains-any"?new Ti(t,r):new j(t,e,r)}static createKeyFieldInFilter(t,e,r){return e==="in"?new Ei(t,r):new Ii(t,r)}matches(t){const e=t.data.field(this.field);return this.op==="!="?e!==null&&e.nullValue===void 0&&this.matchesComparison(qt(e,this.value)):e!==null&&st(this.value)===st(e)&&this.matchesComparison(qt(e,this.value))}matchesComparison(t){switch(this.op){case"<":return t<0;case"<=":return t<=0;case"==":return t===0;case"!=":return t!==0;case">":return t>0;case">=":return t>=0;default:return V(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Nt extends Jn{constructor(t,e){super(),this.filters=t,this.op=e,this.Ae=null}static create(t,e){return new Nt(t,e)}matches(t){return(function(r){return r.op==="and"})(this)?this.filters.find((e=>!e.matches(t)))===void 0:this.filters.find((e=>e.matches(t)))!==void 0}getFlattenedFilters(){return this.Ae!==null||(this.Ae=this.filters.reduce(((t,e)=>t.concat(e.getFlattenedFilters())),[])),this.Ae}getFilters(){return Object.assign([],this.filters)}}class yi extends j{constructor(t,e,r){super(t,e,r),this.key=O.fromName(r.referenceValue)}matches(t){const e=O.comparator(t.key,this.key);return this.matchesComparison(e)}}class Ei extends j{constructor(t,e){super(t,"in",e),this.keys=Qn("in",e)}matches(t){return this.keys.some((e=>e.isEqual(t.key)))}}class Ii extends j{constructor(t,e){super(t,"not-in",e),this.keys=Qn("not-in",e)}matches(t){return!this.keys.some((e=>e.isEqual(t.key)))}}function Qn(n,t){return(t.arrayValue?.values||[]).map((e=>O.fromName(e.referenceValue)))}class Ai extends j{constructor(t,e){super(t,"array-contains",e)}matches(t){const e=t.data.field(this.field);return Kn(e)&&bt(e.arrayValue,this.value)}}class wi extends j{constructor(t,e){super(t,"in",e)}matches(t){const e=t.data.field(this.field);return e!==null&&bt(this.value.arrayValue,e)}}class bi extends j{constructor(t,e){super(t,"not-in",e)}matches(t){if(bt(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const e=t.data.field(this.field);return e!==null&&e.nullValue===void 0&&!bt(this.value.arrayValue,e)}}class Ti extends j{constructor(t,e){super(t,"array-contains-any",e)}matches(t){const e=t.data.field(this.field);return!(!Kn(e)||!e.arrayValue.values)&&e.arrayValue.values.some((r=>bt(this.value.arrayValue,r)))}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gt{constructor(t,e="asc"){this.field=t,this.dir=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class M{static fromTimestamp(t){return new M(t)}static min(){return new M(new T(0,0))}static max(){return new M(new T(253402300799,999999999))}constructor(t){this.timestamp=t}compareTo(t){return this.timestamp._compareTo(t.timestamp)}isEqual(t){return this.timestamp.isEqual(t.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ht{constructor(t,e){this.comparator=t,this.root=e||k.EMPTY}insert(t,e){return new Ht(this.comparator,this.root.insert(t,e,this.comparator).copy(null,null,k.BLACK,null,null))}remove(t){return new Ht(this.comparator,this.root.remove(t,this.comparator).copy(null,null,k.BLACK,null,null))}get(t){let e=this.root;for(;!e.isEmpty();){const r=this.comparator(t,e.key);if(r===0)return e.value;r<0?e=e.left:r>0&&(e=e.right)}return null}indexOf(t){let e=0,r=this.root;for(;!r.isEmpty();){const s=this.comparator(t,r.key);if(s===0)return e+r.left.size;s<0?r=r.left:(e+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(t){return this.root.inorderTraversal(t)}forEach(t){this.inorderTraversal(((e,r)=>(t(e,r),!1)))}toString(){const t=[];return this.inorderTraversal(((e,r)=>(t.push(`${e}:${r}`),!1))),`{${t.join(", ")}}`}reverseTraversal(t){return this.root.reverseTraversal(t)}getIterator(){return new Ft(this.root,null,this.comparator,!1)}getIteratorFrom(t){return new Ft(this.root,t,this.comparator,!1)}getReverseIterator(){return new Ft(this.root,null,this.comparator,!0)}getReverseIteratorFrom(t){return new Ft(this.root,t,this.comparator,!0)}}class Ft{constructor(t,e,r,s){this.isReverse=s,this.nodeStack=[];let i=1;for(;!t.isEmpty();)if(i=e?r(t.key,e):1,e&&s&&(i*=-1),i<0)t=this.isReverse?t.left:t.right;else{if(i===0){this.nodeStack.push(t);break}this.nodeStack.push(t),t=this.isReverse?t.right:t.left}}getNext(){let t=this.nodeStack.pop();const e={key:t.key,value:t.value};if(this.isReverse)for(t=t.left;!t.isEmpty();)this.nodeStack.push(t),t=t.right;else for(t=t.right;!t.isEmpty();)this.nodeStack.push(t),t=t.left;return e}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const t=this.nodeStack[this.nodeStack.length-1];return{key:t.key,value:t.value}}}class k{constructor(t,e,r,s,i){this.key=t,this.value=e,this.color=r??k.RED,this.left=s??k.EMPTY,this.right=i??k.EMPTY,this.size=this.left.size+1+this.right.size}copy(t,e,r,s,i){return new k(t??this.key,e??this.value,r??this.color,s??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(t){return this.left.inorderTraversal(t)||t(this.key,this.value)||this.right.inorderTraversal(t)}reverseTraversal(t){return this.right.reverseTraversal(t)||t(this.key,this.value)||this.left.reverseTraversal(t)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(t,e,r){let s=this;const i=r(t,s.key);return s=i<0?s.copy(null,null,null,s.left.insert(t,e,r),null):i===0?s.copy(null,e,null,null,null):s.copy(null,null,null,null,s.right.insert(t,e,r)),s.fixUp()}removeMin(){if(this.left.isEmpty())return k.EMPTY;let t=this;return t.left.isRed()||t.left.left.isRed()||(t=t.moveRedLeft()),t=t.copy(null,null,null,t.left.removeMin(),null),t.fixUp()}remove(t,e){let r,s=this;if(e(t,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(t,e),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),e(t,s.key)===0){if(s.right.isEmpty())return k.EMPTY;r=s.right.min(),s=s.copy(r.key,r.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(t,e))}return s.fixUp()}isRed(){return this.color}fixUp(){let t=this;return t.right.isRed()&&!t.left.isRed()&&(t=t.rotateLeft()),t.left.isRed()&&t.left.left.isRed()&&(t=t.rotateRight()),t.left.isRed()&&t.right.isRed()&&(t=t.colorFlip()),t}moveRedLeft(){let t=this.colorFlip();return t.right.left.isRed()&&(t=t.copy(null,null,null,null,t.right.rotateRight()),t=t.rotateLeft(),t=t.colorFlip()),t}moveRedRight(){let t=this.colorFlip();return t.left.left.isRed()&&(t=t.rotateRight(),t=t.colorFlip()),t}rotateLeft(){const t=this.copy(null,null,k.RED,null,this.right.left);return this.right.copy(null,null,this.color,t,null)}rotateRight(){const t=this.copy(null,null,k.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,t)}colorFlip(){const t=this.left.copy(null,null,!this.left.color,null,null),e=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,t,e)}checkMaxDepth(){const t=this.check();return Math.pow(2,t)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw V(43730,{key:this.key,value:this.value});if(this.right.isRed())throw V(14113,{key:this.key,value:this.value});const t=this.left.check();if(t!==this.right.check())throw V(27949);return t+(this.isRed()?0:1)}}k.EMPTY=null,k.RED=!0,k.BLACK=!1;k.EMPTY=new class{constructor(){this.size=0}get key(){throw V(57766)}get value(){throw V(16141)}get color(){throw V(16727)}get left(){throw V(29726)}get right(){throw V(36894)}copy(t,e,r,s,i){return this}insert(t,e,r){return new k(t,e)}remove(t,e){return this}isEmpty(){return!0}inorderTraversal(t){return!1}reverseTraversal(t){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tt{constructor(t){this.comparator=t,this.data=new Ht(this.comparator)}has(t){return this.data.get(t)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(t){return this.data.indexOf(t)}forEach(t){this.data.inorderTraversal(((e,r)=>(t(e),!1)))}forEachInRange(t,e){const r=this.data.getIteratorFrom(t[0]);for(;r.hasNext();){const s=r.getNext();if(this.comparator(s.key,t[1])>=0)return;e(s.key)}}forEachWhile(t,e){let r;for(r=e!==void 0?this.data.getIteratorFrom(e):this.data.getIterator();r.hasNext();)if(!t(r.getNext().key))return}firstAfterOrEqual(t){const e=this.data.getIteratorFrom(t);return e.hasNext()?e.getNext().key:null}getIterator(){return new gn(this.data.getIterator())}getIteratorFrom(t){return new gn(this.data.getIteratorFrom(t))}add(t){return this.copy(this.data.remove(t).insert(t,!0))}delete(t){return this.has(t)?this.copy(this.data.remove(t)):this}isEmpty(){return this.data.isEmpty()}unionWith(t){let e=this;return e.size<t.size&&(e=t,t=this),t.forEach((r=>{e=e.add(r)})),e}isEqual(t){if(!(t instanceof Tt)||this.size!==t.size)return!1;const e=this.data.getIterator(),r=t.data.getIterator();for(;e.hasNext();){const s=e.getNext().key,i=r.getNext().key;if(this.comparator(s,i)!==0)return!1}return!0}toArray(){const t=[];return this.forEach((e=>{t.push(e)})),t}toString(){const t=[];return this.forEach((e=>t.push(e))),"SortedSet("+t.toString()+")"}copy(t){const e=new Tt(this.comparator);return e.data=t,e}}class gn{constructor(t){this.iter=t}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class it{constructor(t){this.fields=t,t.sort(X.comparator)}static empty(){return new it([])}unionWith(t){let e=new Tt(X.comparator);for(const r of this.fields)e=e.add(r);for(const r of t)e=e.add(r);return new it(e.toArray())}covers(t){for(const e of this.fields)if(e.isPrefixOf(t))return!0;return!1}isEqual(t){return $n(this.fields,t.fields,((e,r)=>e.isEqual(r)))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class L{constructor(t){this.value=t}static empty(){return new L({mapValue:{}})}field(t){if(t.isEmpty())return this.value;{let e=this.value;for(let r=0;r<t.length-1;++r)if(e=(e.mapValue.fields||{})[t.get(r)],!ce(e))return null;return e=(e.mapValue.fields||{})[t.lastSegment()],e||null}}set(t,e){this.getFieldsMap(t.popLast())[t.lastSegment()]=mt(e)}setAll(t){let e=X.emptyPath(),r={},s=[];t.forEach(((a,d)=>{if(!e.isImmediateParentOf(d)){const m=this.getFieldsMap(e);this.applyChanges(m,r,s),r={},s=[],e=d.popLast()}a?r[d.lastSegment()]=mt(a):s.push(d.lastSegment())}));const i=this.getFieldsMap(e);this.applyChanges(i,r,s)}delete(t){const e=this.field(t.popLast());ce(e)&&e.mapValue.fields&&delete e.mapValue.fields[t.lastSegment()]}isEqual(t){return zt(this.value,t.value)}getFieldsMap(t){let e=this.value;e.mapValue.fields||(e.mapValue={fields:{}});for(let r=0;r<t.length;++r){let s=e.mapValue.fields[t.get(r)];ce(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},e.mapValue.fields[t.get(r)]=s),e=s}return e.mapValue.fields}applyChanges(t,e,r){Vt(e,((s,i)=>t[s]=i));for(const s of r)delete t[s]}clone(){return new L(mt(this.value))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Q{constructor(t,e,r,s,i,a,d){this.key=t,this.documentType=e,this.version=r,this.readTime=s,this.createTime=i,this.data=a,this.documentState=d}static newInvalidDocument(t){return new Q(t,0,M.min(),M.min(),M.min(),L.empty(),0)}static newFoundDocument(t,e,r,s){return new Q(t,1,e,M.min(),r,s,0)}static newNoDocument(t,e){return new Q(t,2,e,M.min(),M.min(),L.empty(),0)}static newUnknownDocument(t,e){return new Q(t,3,e,M.min(),M.min(),L.empty(),2)}convertToFoundDocument(t,e){return!this.createTime.isEqual(M.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=t),this.version=t,this.documentType=1,this.data=e,this.documentState=0,this}convertToNoDocument(t){return this.version=t,this.documentType=2,this.data=L.empty(),this.documentState=0,this}convertToUnknownDocument(t){return this.version=t,this.documentType=3,this.data=L.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=M.min(),this}setReadTime(t){return this.readTime=t,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(t){return t instanceof Q&&this.key.isEqual(t.key)&&this.version.isEqual(t.version)&&this.documentType===t.documentType&&this.documentState===t.documentState&&this.data.isEqual(t.data)}mutableCopy(){return new Q(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vi{constructor(t,e=null,r=[],s=[],i=null,a=null,d=null){this.path=t,this.collectionGroup=e,this.orderBy=r,this.filters=s,this.limit=i,this.startAt=a,this.endAt=d,this.Ie=null}}function _n(n,t=null,e=[],r=[],s=null,i=null,a=null){return new vi(n,t,e,r,s,i,a)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yt{constructor(t,e=null,r=[],s=[],i=null,a="F",d=null,m=null){this.path=t,this.collectionGroup=e,this.explicitOrderBy=r,this.filters=s,this.limit=i,this.limitType=a,this.startAt=d,this.endAt=m,this.pe=null,this.ye=null,this.we=null,this.startAt,this.endAt}}function Vi(n){return n.collectionGroup!==null}function Si(n){const t=Kt(n);if(t.pe===null){t.pe=[];const e=new Set;for(const i of t.explicitOrderBy)t.pe.push(i),e.add(i.field.canonicalString());const r=t.explicitOrderBy.length>0?t.explicitOrderBy[t.explicitOrderBy.length-1].dir:"asc";(function(a){let d=new Tt(X.comparator);return a.filters.forEach((m=>{m.getFlattenedFilters().forEach((g=>{g.isInequality()&&(d=d.add(g.field))}))})),d})(t).forEach((i=>{e.has(i.canonicalString())||i.isKeyField()||t.pe.push(new Gt(i,r))})),e.has(X.keyField().canonicalString())||t.pe.push(new Gt(X.keyField(),r))}return t.pe}function Ni(n){const t=Kt(n);return t.ye||(t.ye=Ri(t,Si(n))),t.ye}function Ri(n,t){if(n.limitType==="F")return _n(n.path,n.collectionGroup,t,n.filters,n.limit,n.startAt,n.endAt);{t=t.map((s=>{const i=s.dir==="desc"?"asc":"desc";return new Gt(s.field,i)}));const e=n.endAt?new mn(n.endAt.position,n.endAt.inclusive):null,r=n.startAt?new mn(n.startAt.position,n.startAt.inclusive):null;return _n(n.path,n.collectionGroup,t,n.filters,n.limit,e,r)}}function ye(n,t){const e=n.filters.concat([t]);return new Yt(n.path,n.collectionGroup,n.explicitOrderBy.slice(),e,n.limit,n.limitType,n.startAt,n.endAt)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yn(n,t){if(n.useProto3Json){if(isNaN(t))return{doubleValue:"NaN"};if(t===1/0)return{doubleValue:"Infinity"};if(t===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Bt(t)?"-0":t}}function Pi(n,t,e){return(function(s){return typeof s=="number"&&Number.isInteger(s)&&!Bt(s)&&s<=Number.MAX_SAFE_INTEGER&&s>=Number.MIN_SAFE_INTEGER})(t)?(function(s){return{integerValue:""+s}})(t):Yn(n,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xt{constructor(){this._=void 0}}class Xn extends Xt{}class Di extends Xt{constructor(t){super(),this.elements=t}}class Ci extends Xt{constructor(t){super(),this.elements=t}}class ve extends Xt{constructor(t,e){super(),this.serializer=t,this.ge=e}}class Oi extends ve{}class ki extends ve{}class Fi extends ve{}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mi{constructor(t,e){this.field=t,this.transform=e}}class ct{constructor(t,e){this.updateTime=t,this.exists=e}static none(){return new ct}static exists(t){return new ct(void 0,t)}static updateTime(t){return new ct(t)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(t){return this.exists===t.exists&&(this.updateTime?!!t.updateTime&&this.updateTime.isEqual(t.updateTime):!t.updateTime)}}class Zt{}class Zn extends Zt{constructor(t,e,r,s=[]){super(),this.key=t,this.value=e,this.precondition=r,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class Ve extends Zt{constructor(t,e,r,s,i=[]){super(),this.key=t,this.data=e,this.fieldMask=r,this.precondition=s,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}class xi extends Zt{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Li extends Zt{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ui={asc:"ASCENDING",desc:"DESCENDING"},$i={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},Bi={and:"AND",or:"OR"};class ji{constructor(t,e){this.databaseId=t,this.useProto3Json=e}}function Mt(n,t){return n.useProto3Json?`${new Date(1e3*t.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+t.nanoseconds).slice(-9)}Z`:{seconds:""+t.seconds,nanos:t.nanoseconds}}function zi(n,t){return n.useProto3Json?t.toBase64():t.toUint8Array()}function qi(n,t){return Mt(n,t.toTimestamp())}function yn(n){return Z(!!n,49232),M.fromTimestamp((function(e){const r=rt(e);return new T(r.seconds,r.nanos)})(n))}function Se(n,t){return Ee(n,t).canonicalString()}function Ee(n,t){const e=(function(s){return new D(["projects",s.projectId,"databases",s.database])})(n).child("documents");return t===void 0?e:e.child(t)}function Ie(n,t){return Se(n.databaseId,t.path)}function Gi(n,t){const e=(function(s){const i=D.fromString(s);return Z(er(i),10190,{key:i.toString()}),i})(t);if(e.get(1)!==n.databaseId.projectId)throw new E(_.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+e.get(1)+" vs "+n.databaseId.projectId);if(e.get(3)!==n.databaseId.database)throw new E(_.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+e.get(3)+" vs "+n.databaseId.database);return new O((function(s){return Z(s.length>4&&s.get(4)==="documents",29091,{key:s.toString()}),s.popFirst(5)})(e))}function En(n,t,e){return{name:Ie(n,t),fields:e.value.mapValue.fields}}function Hi(n,t){let e;if(t instanceof Zn)e={update:En(n,t.key,t.value)};else if(t instanceof xi)e={delete:Ie(n,t.key)};else if(t instanceof Ve)e={update:En(n,t.key,t.data),updateMask:Yi(t.fieldMask)};else{if(!(t instanceof Li))return V(16599,{Fe:t.type});e={verify:Ie(n,t.key)}}return t.fieldTransforms.length>0&&(e.updateTransforms=t.fieldTransforms.map((r=>(function(i,a){const d=a.transform;if(d instanceof Xn)return{fieldPath:a.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(d instanceof Di)return{fieldPath:a.field.canonicalString(),appendMissingElements:{values:d.elements}};if(d instanceof Ci)return{fieldPath:a.field.canonicalString(),removeAllFromArray:{values:d.elements}};if(d instanceof Oi)return{fieldPath:a.field.canonicalString(),increment:d.ge};if(d instanceof ki)return{fieldPath:a.field.canonicalString(),minimum:d.ge};if(d instanceof Fi)return{fieldPath:a.field.canonicalString(),maximum:d.ge};throw V(20930,{transform:a.transform})})(0,r)))),t.precondition.isNone||(e.currentDocument=(function(s,i){return i.updateTime!==void 0?{updateTime:qi(s,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:V(27497)})(n,t.precondition)),e}function Wi(n,t){const e={structuredQuery:{}},r=t.path;let s;t.collectionGroup!==null?(s=r,e.structuredQuery.from=[{collectionId:t.collectionGroup,allDescendants:!0}]):(s=r.popLast(),e.structuredQuery.from=[{collectionId:r.lastSegment()}]),e.parent=(function(g,y){return Se(g.databaseId,y)})(n,s);const i=(function(g){if(g.length!==0)return tr(Nt.create(g,"and"))})(t.filters);i&&(e.structuredQuery.where=i);const a=(function(g){if(g.length!==0)return g.map((y=>(function(A){return{field:lt(A.field),direction:Ki(A.dir)}})(y)))})(t.orderBy);a&&(e.structuredQuery.orderBy=a);const d=(function(g,y){return g.useProto3Json||hi(y)?y:{value:y}})(n,t.limit);return d!==null&&(e.structuredQuery.limit=d),t.startAt&&(e.structuredQuery.startAt=(function(g){return{before:g.inclusive,values:g.position}})(t.startAt)),t.endAt&&(e.structuredQuery.endAt=(function(g){return{before:!g.inclusive,values:g.position}})(t.endAt)),{ve:e,parent:s}}function Ki(n){return Ui[n]}function Ji(n){return $i[n]}function Qi(n){return Bi[n]}function lt(n){return{fieldPath:n.canonicalString()}}function tr(n){return n instanceof j?(function(e){if(e.op==="=="){if(pn(e.value))return{unaryFilter:{field:lt(e.field),op:"IS_NAN"}};if(dn(e.value))return{unaryFilter:{field:lt(e.field),op:"IS_NULL"}}}else if(e.op==="!="){if(pn(e.value))return{unaryFilter:{field:lt(e.field),op:"IS_NOT_NAN"}};if(dn(e.value))return{unaryFilter:{field:lt(e.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:lt(e.field),op:Ji(e.op),value:e.value}}})(n):n instanceof Nt?(function(e){const r=e.getFilters().map((s=>tr(s)));return r.length===1?r[0]:{compositeFilter:{op:Qi(e.op),filters:r}}})(n):V(54877,{filter:n})}function Yi(n){const t=[];return n.fields.forEach((e=>t.push(e.canonicalString()))),{fieldPaths:t}}function er(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function nr(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ne(n){return new ji(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xi{}class Zi extends Xi{constructor(t,e,r,s){super(),this.authCredentials=t,this.appCheckCredentials=e,this.connection=r,this.serializer=s,this.be=!1}De(){if(this.be)throw new E(_.FAILED_PRECONDITION,"The client has already been terminated.")}le(t,e,r,s){return this.De(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([i,a])=>this.connection.le(t,Ee(e,r),s,i,a))).catch((i=>{throw i.name==="FirebaseError"?(i.code===_.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new E(_.UNKNOWN,i.toString())}))}de(t,e,r,s,i){return this.De(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([a,d])=>this.connection.de(t,Ee(e,r),s,a,d,i))).catch((a=>{throw a.name==="FirebaseError"?(a.code===_.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),a):new E(_.UNKNOWN,a.toString())}))}terminate(){this.be=!0,this.connection.terminate()}}async function rr(n,t){const e=Kt(n),r={writes:t.map((s=>Hi(e.serializer,s)))};await e.le("Commit",e.serializer.databaseId,D.emptyPath(),r)}async function to(n,t){const e=Kt(n),{ve:r,parent:s}=Wi(e.serializer,Ni(t));return(await e.de("RunQuery",e.serializer.databaseId,s,{structuredQuery:r.structuredQuery})).filter((i=>!!i.document)).map((i=>(function(d,m,g){const y=Gi(d,m.name),I=yn(m.updateTime),A=m.createTime?yn(m.createTime):M.min(),S=new L({mapValue:{fields:m.fields}}),v=Q.newFoundDocument(y,I,A,S);return g?v.setHasCommittedMutations():v})(e.serializer,i.document,void 0)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sr="ComponentProvider",gt=new Map;function Re(n){if(n._terminated)throw new E(_.FAILED_PRECONDITION,"The client has already been terminated.");if(!gt.has(n)){$t(sr,"Initializing Datastore");const t=(function(i){return new pi(i)})((function(i,a,d,m,g){return new ri(i,a,d,g.host,g.ssl,g.experimentalForceLongPolling,g.experimentalAutoDetectLongPolling,zn(g.experimentalLongPollingOptions),g.useFetchStreams,g.isUsingEmulator,m,g._customHeaders,g.grpcFlowControlWindow)})(n._databaseId,n.app.options.appId||"",n._persistenceKey,n.app.options.apiKey,n._freezeSettings())),e=Ne(n._databaseId),r=(function(i,a,d,m){return new Zi(i,a,d,m)})(n._authCredentials,n._appCheckCredentials,t,e);gt.set(n,r)}return gt.get(n)}const eo=1048576,ir="firestore.googleapis.com",In=!0;class An{constructor(t){if(t.host===void 0){if(t.ssl!==void 0)throw new E(_.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=ir,this.ssl=In}else this.host=t.host,this.ssl=t.ssl??In;if(this.isUsingEmulator=t.emulatorOptions!==void 0,this.credentials=t.credentials,this.ignoreUndefinedProperties=!!t.ignoreUndefinedProperties,this.localCache=t.localCache,t._customHeaders&&(this._customHeaders={...t._customHeaders}),t.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(t.cacheSizeBytes!==-1&&t.cacheSizeBytes<eo)throw new E(_.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=t.cacheSizeBytes}if((function(r,s,i,a){if(s===!0&&a===!0)throw new E(_.INVALID_ARGUMENT,`${r} and ${i} cannot be used together.`)})("experimentalForceLongPolling",t.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",t.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!t.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:t.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!t.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=zn(t.experimentalLongPollingOptions??{}),(function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new E(_.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new E(_.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new E(_.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}})(this.experimentalLongPollingOptions),this.useFetchStreams=!!t.useFetchStreams,t.grpcFlowControlWindow!==void 0){if(typeof t.grpcFlowControlWindow!="number"||t.grpcFlowControlWindow<=0||t.grpcFlowControlWindow>2147483647||!Number.isInteger(t.grpcFlowControlWindow))throw new E(_.INVALID_ARGUMENT,"grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");this.grpcFlowControlWindow=t.grpcFlowControlWindow}}isEqual(t){return this.host===t.host&&this.ssl===t.ssl&&this.credentials===t.credentials&&this.cacheSizeBytes===t.cacheSizeBytes&&this.experimentalForceLongPolling===t.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===t.experimentalAutoDetectLongPolling&&(function(r,s){return r.timeoutSeconds===s.timeoutSeconds})(this.experimentalLongPollingOptions,t.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===t.ignoreUndefinedProperties&&this.useFetchStreams===t.useFetchStreams&&this.grpcFlowControlWindow===t.grpcFlowControlWindow&&(function(r,s){if(r===s)return!0;if(!r||!s)return!1;const i=Object.keys(r),a=Object.keys(s);if(i.length!==a.length)return!1;for(const d of i)if(r[d]!==s[d])return!1;return!0})(this._customHeaders,t._customHeaders)}}class te{constructor(t,e,r,s){this._authCredentials=t,this._appCheckCredentials=e,this._databaseId=r,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new An({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new E(_.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(t){if(this._settingsFrozen)throw new E(_.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new An(t),this._emulatorOptions=t.emulatorOptions||{},t.credentials!==void 0&&(this._authCredentials=(function(r){if(!r)return new Ys;switch(r.type){case"firstParty":return new ei(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new E(_.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}})(t.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return(function(e){const r=gt.get(e);r&&($t(sr,"Removing Datastore"),gt.delete(e),r.terminate())})(this),Promise.resolve()}}function Do(n,t){const e=typeof n=="object"?n:xs(),r=typeof n=="string"?n:"(default)",s=Ds(e,"firestore/lite").getImmediate({identifier:r});if(!s._initialized){const i=vr("firestore");i&&no(s,...i)}return s}function no(n,t,e,r={}){n=Qt(n,te);const s=Pn(t),i=n._getSettings(),a={...i,emulatorOptions:n._getEmulatorOptions()},d=`${t}:${e}`;s&&kr(`https://${d}`),i.host!==ir&&i.host!==d&&xn("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const m={...i,host:d,ssl:s,emulatorOptions:r};if(!Lt(m,a)&&(n._setSettings(m),r.mockUserToken)){let g,y;if(typeof r.mockUserToken=="string")g=r.mockUserToken,y=x.MOCK_USER;else{g=Sr(r.mockUserToken,n._app?.options.projectId);const I=r.mockUserToken.sub||r.mockUserToken.user_id;if(!I)throw new E(_.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");y=new x(I)}n._authCredentials=new Xs(new Un(g,y))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tt{constructor(t,e,r){this.converter=e,this._query=r,this.type="query",this.firestore=t}withConverter(t){return new tt(this.firestore,t,this._query)}}class C{constructor(t,e,r){this.converter=e,this._key=r,this.type="document",this.firestore=t}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new H(this.firestore,this.converter,this._key.path.popLast())}withConverter(t){return new C(this.firestore,t,this._key)}toJSON(){return{type:C._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(t,e,r){if(St(e,C._jsonSchema))return new C(t,r||null,new O(D.fromString(e.referencePath)))}}C._jsonSchemaVersion="firestore/documentReference/1.0",C._jsonSchema={type:$("string",C._jsonSchemaVersion),referencePath:$("string")};class H extends tt{constructor(t,e,r){super(t,e,(function(i){return new Yt(i)})(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const t=this._path.popLast();return t.isEmpty()?null:new C(this.firestore,null,new O(t))}withConverter(t){return new H(this.firestore,t,this._path)}}function Co(n,t,...e){if(n=W(n),Bn("collection","path",t),n instanceof te){const r=D.fromString(t,...e);return rn(r),new H(n,null,r)}{if(!(n instanceof C||n instanceof H))throw new E(_.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(D.fromString(t,...e));return rn(r),new H(n.firestore,null,r)}}function ro(n,t,...e){if(n=W(n),arguments.length===1&&(t=oi.newId()),Bn("doc","path",t),n instanceof te){const r=D.fromString(t,...e);return nn(r),new C(n,null,new O(r))}{if(!(n instanceof C||n instanceof H))throw new E(_.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(D.fromString(t,...e));return nn(r),new C(n.firestore,n instanceof H?n.converter:null,new O(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U{constructor(t){this._byteString=t}static fromBase64String(t){try{return new U(J.fromBase64String(t))}catch(e){throw new E(_.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+e)}}static fromUint8Array(t){return new U(J.fromUint8Array(t))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(t){return this._byteString.isEqual(t._byteString)}toJSON(){return{type:U._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(t){if(St(t,U._jsonSchema))return U.fromBase64String(t.bytes)}}U._jsonSchemaVersion="firestore/bytes/1.0",U._jsonSchema={type:$("string",U._jsonSchemaVersion),bytes:$("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pe{constructor(...t){for(let e=0;e<t.length;++e)if(t[e].length===0)throw new E(_.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new X(t)}isEqual(t){return this._internalPath.isEqual(t._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ee{constructor(t){this._methodName=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class q{constructor(t,e){if(!isFinite(t)||t<-90||t>90)throw new E(_.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+t);if(!isFinite(e)||e<-180||e>180)throw new E(_.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+e);this._lat=t,this._long=e}get latitude(){return this._lat}get longitude(){return this._long}isEqual(t){return this._lat===t._lat&&this._long===t._long}_compareTo(t){return R(this._lat,t._lat)||R(this._long,t._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:q._jsonSchemaVersion}}static fromJSON(t){if(St(t,q._jsonSchema))return new q(t.latitude,t.longitude)}}q._jsonSchemaVersion="firestore/geoPoint/1.0",q._jsonSchema={type:$("string",q._jsonSchemaVersion),latitude:$("number"),longitude:$("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class B{constructor(t){this._values=(t||[]).map((e=>e))}toArray(){return this._values.map((t=>t))}isEqual(t){/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return(function(r,s){if(r.length!==s.length)return!1;for(let i=0;i<r.length;++i)if(r[i]!==s[i])return!1;return!0})(this._values,t._values)}toJSON(){return{type:B._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(t){if(St(t,B._jsonSchema)){if(Array.isArray(t.vectorValues)&&t.vectorValues.every((e=>typeof e=="number")))return new B(t.vectorValues);throw new E(_.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}B._jsonSchemaVersion="firestore/vectorValue/1.0",B._jsonSchema={type:$("string",B._jsonSchemaVersion),vectorValues:$("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const so=/^__.*__$/;class io{constructor(t,e,r){this.data=t,this.fieldMask=e,this.fieldTransforms=r}toMutation(t,e){return this.fieldMask!==null?new Ve(t,this.data,this.fieldMask,e,this.fieldTransforms):new Zn(t,this.data,e,this.fieldTransforms)}}class or{constructor(t,e,r){this.data=t,this.fieldMask=e,this.fieldTransforms=r}toMutation(t,e){return new Ve(t,this.data,this.fieldMask,e,this.fieldTransforms)}}function ar(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw V(40011,{dataSource:n})}}class De{constructor(t,e,r,s,i,a){this.settings=t,this.databaseId=e,this.serializer=r,this.ignoreUndefinedProperties=s,i===void 0&&this.validatePath(),this.fieldTransforms=i||[],this.fieldMask=a||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}contextWith(t){return new De({...this.settings,...t},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}childContextForField(t){const e=this.path?.child(t),r=this.contextWith({path:e,arrayElement:!1});return r.validatePathSegment(t),r}childContextForFieldPath(t){const e=this.path?.child(t),r=this.contextWith({path:e,arrayElement:!1});return r.validatePath(),r}childContextForArray(t){return this.contextWith({path:void 0,arrayElement:!0})}createError(t){return Wt(t,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(t){return this.fieldMask.find((e=>t.isPrefixOf(e)))!==void 0||this.fieldTransforms.find((e=>t.isPrefixOf(e.field)))!==void 0}validatePath(){if(this.path)for(let t=0;t<this.path.length;t++)this.validatePathSegment(this.path.get(t))}validatePathSegment(t){if(t.length===0)throw this.createError("Document fields must not be empty");if(ar(this.dataSource)&&so.test(t))throw this.createError('Document fields cannot begin and end with "__"')}}class oo{constructor(t,e,r){this.databaseId=t,this.ignoreUndefinedProperties=e,this.serializer=r||Ne(t)}createContext(t,e,r,s=!1){return new De({dataSource:t,methodName:e,targetDoc:r,path:X.emptyPath(),arrayElement:!1,hasConverter:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Ce(n){const t=n._freezeSettings(),e=Ne(n._databaseId);return new oo(n._databaseId,!!t.ignoreUndefinedProperties,e)}function ao(n,t,e,r,s,i={}){const a=n.createContext(i.merge||i.mergeFields?2:0,t,e,s);ke("Data must be an object, but it was:",a,r);const d=lr(r,a);let m,g;if(i.merge)m=new it(a.fieldMask),g=a.fieldTransforms;else if(i.mergeFields){const y=[];for(const I of i.mergeFields){const A=vt(t,I,e);if(!a.contains(A))throw new E(_.INVALID_ARGUMENT,`Field '${A}' is specified in your field mask but missing from your input data.`);fr(y,A)||y.push(A)}m=new it(y),g=a.fieldTransforms.filter((I=>m.covers(I.field)))}else m=null,g=a.fieldTransforms;return new io(new L(d),m,g)}class ne extends ee{_toFieldTransform(t){if(t.dataSource!==2)throw t.dataSource===1?t.createError(`${this._methodName}() can only appear at the top level of your update data`):t.createError(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return t.fieldMask.push(t.path),null}isEqual(t){return t instanceof ne}}class Oe extends ee{_toFieldTransform(t){return new Mi(t.path,new Xn)}isEqual(t){return t instanceof Oe}}function lo(n,t,e,r){const s=n.createContext(1,t,e);ke("Data must be an object, but it was:",s,r);const i=[],a=L.empty();Vt(r,((m,g)=>{const y=hr(t,m,e);g=W(g);const I=s.childContextForFieldPath(y);if(g instanceof ne)i.push(y);else{const A=Rt(g,I);A!=null&&(i.push(y),a.set(y,A))}}));const d=new it(i);return new or(a,d,s.fieldTransforms)}function uo(n,t,e,r,s,i){const a=n.createContext(1,t,e),d=[vt(t,r,e)],m=[s];if(i.length%2!=0)throw new E(_.INVALID_ARGUMENT,`Function ${t}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let A=0;A<i.length;A+=2)d.push(vt(t,i[A])),m.push(i[A+1]);const g=[],y=L.empty();for(let A=d.length-1;A>=0;--A)if(!fr(g,d[A])){const S=d[A];let v=m[A];v=W(v);const F=a.childContextForFieldPath(S);if(v instanceof ne)g.push(S);else{const N=Rt(v,F);N!=null&&(g.push(S),y.set(S,N))}}const I=new it(g);return new or(y,I,a.fieldTransforms)}function co(n,t,e,r=!1){return Rt(e,n.createContext(r?4:3,t))}function Rt(n,t,e){if(cr(n=W(n)))return ke("Unsupported field value:",t,n),lr(n,t);if(n instanceof ee)return(function(s,i){if(!ar(i.dataSource))throw i.createError(`${s._methodName}() can only be used with update() and set()`);if(!i.path)throw i.createError(`${s._methodName}() is not currently supported inside arrays`);const a=s._toFieldTransform(i);a&&i.fieldTransforms.push(a)})(n,t),null;if(n===void 0&&t.ignoreUndefinedProperties)return null;if(t.path&&t.fieldMask.push(t.path),n instanceof Array){if(t.settings.arrayElement&&t.dataSource!==4)throw t.createError("Nested arrays are not supported");return(function(s,i){const a=[];let d=0;for(const m of s){let g=Rt(m,i.childContextForArray(d));g==null&&(g={nullValue:"NULL_VALUE"}),a.push(g),d++}return{arrayValue:{values:a}}})(n,t)}return(function(s,i,a){if((s=W(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return Pi(i.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const d=T.fromDate(s);return{timestampValue:Mt(i.serializer,d)}}if(s instanceof T){const d=new T(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:Mt(i.serializer,d)}}if(ur(s)){const d=T.fromInstant(s),m=new T(d.seconds,1e3*Math.floor(d.nanoseconds/1e3));return{timestampValue:Mt(i.serializer,m)}}if(s instanceof q)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof U)return{bytesValue:zi(i.serializer,s._byteString)};if(s instanceof C){const d=i.databaseId,m=s.firestore._databaseId;if(!m.isEqual(d))throw i.createError(`Document reference is for database ${m.projectId}/${m.database} but should be for database ${d.projectId}/${d.database}`);return{referenceValue:Se(s.firestore._databaseId||i.databaseId,s._key.path)}}if(s instanceof B)return(function(m,g){const y=m instanceof B?m.toArray():m;return{mapValue:{fields:{[Hn]:{stringValue:Wn},[jt]:{arrayValue:{values:y.map((A=>{if(typeof A!="number")throw g.createError("VectorValues must only contain numeric values.");return Yn(g.serializer,A)}))}}}}}})(s,i);if(nr(s))return s._toProto(i.serializer);throw i.createError(`Unsupported field value: ${Jt(s)}`)})(n,t)}function lr(n,t){const e={};return(function(s){for(const i in s)if(Object.prototype.hasOwnProperty.call(s,i))return!1;return!0})(n)?t.path&&t.path.length>0&&t.fieldMask.push(t.path):Vt(n,((r,s)=>{const i=Rt(s,t.childContextForField(r));i!=null&&(e[r]=i)})),{mapValue:{fields:e}}}function ur(n){if(typeof n!="object"||n===null)return!1;if(typeof Temporal<"u"&&typeof Temporal.Instant=="function"&&n instanceof Temporal.Instant)return!0;const t=n;return t[Symbol.toStringTag]==="Temporal.Instant"&&typeof t.Te=="bigint"}function cr(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof T||n instanceof q||n instanceof U||n instanceof C||n instanceof ee||n instanceof B||ur(n)||nr(n))}function ke(n,t,e){if(!cr(e)||!jn(e)){const r=Jt(e);throw r==="an object"?t.createError(n+" a custom object"):t.createError(n+" "+r)}}function vt(n,t,e){if((t=W(t))instanceof Pe)return t._internalPath;if(typeof t=="string")return hr(n,t);throw Wt("Field path arguments must be of type string or ",n,!1,void 0,e)}const ho=new RegExp("[~\\*/\\[\\]]");function hr(n,t,e){if(t.search(ho)>=0)throw Wt(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,e);try{return new Pe(...t.split("."))._internalPath}catch{throw Wt(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,e)}}function Wt(n,t,e,r,s){const i=r&&!r.isEmpty(),a=s!==void 0;let d=`Function ${t}() called with invalid data`;e&&(d+=" (via `toFirestore()`)"),d+=". ";let m="";return(i||a)&&(m+=" (found",i&&(m+=` in field ${r}`),a&&(m+=` in document ${s}`),m+=")"),new E(_.INVALID_ARGUMENT,d+n+m)}function fr(n,t){return n.some((e=>e.isEqual(t)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fo{constructor(t,e,r,s,i){this._firestore=t,this._userDataWriter=e,this._key=r,this._document=s,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new C(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const t=new dr(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(t)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){return this._document?.data.clone().value.mapValue.fields??void 0}get(t){if(this._document){const e=this._document.data.field(vt("DocumentSnapshot.get",t));if(e!==null)return this._userDataWriter.convertValue(e)}}}class dr extends fo{data(){return super.data()}}class po{constructor(t,e){this._docs=e,this.query=t}get docs(){return[...this._docs]}get size(){return this.docs.length}get empty(){return this.docs.length===0}forEach(t,e){this._docs.forEach(t,e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fe{}class Me extends Fe{}function Oo(n,t,...e){let r=[];t instanceof Fe&&r.push(t),r=r.concat(e),(function(i){const a=i.filter((m=>m instanceof Le)).length,d=i.filter((m=>m instanceof xe)).length;if(a>1||a>0&&d>0)throw new E(_.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")})(r);for(const s of r)n=s._apply(n);return n}class xe extends Me{constructor(t,e,r){super(),this._field=t,this._op=e,this._value=r,this.type="where"}static _create(t,e,r){return new xe(t,e,r)}_apply(t){const e=this._parse(t);return pr(t._query,e),new tt(t.firestore,t.converter,ye(t._query,e))}_parse(t){const e=Ce(t.firestore);return(function(i,a,d,m,g,y,I){let A;if(g.isKeyField()){if(y==="array-contains"||y==="array-contains-any")throw new E(_.INVALID_ARGUMENT,`Invalid Query. You can't perform '${y}' queries on documentId().`);if(y==="in"||y==="not-in"){bn(I,y);const v=[];for(const F of I)v.push(wn(m,i,F));A={arrayValue:{values:v}}}else A=wn(m,i,I)}else y!=="in"&&y!=="not-in"&&y!=="array-contains-any"||bn(I,y),A=co(d,a,I,y==="in"||y==="not-in");return j.create(g,y,A)})(t._query,"where",e,t.firestore._databaseId,this._field,this._op,this._value)}}class Le extends Fe{constructor(t,e){super(),this.type=t,this._queryConstraints=e}static _create(t,e){return new Le(t,e)}_parse(t){const e=this._queryConstraints.map((r=>r._parse(t))).filter((r=>r.getFilters().length>0));return e.length===1?e[0]:Nt.create(e,this._getOperator())}_apply(t){const e=this._parse(t);return e.getFilters().length===0?t:((function(s,i){let a=s;const d=i.getFlattenedFilters();for(const m of d)pr(a,m),a=ye(a,m)})(t._query,e),new tt(t.firestore,t.converter,ye(t._query,e)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Ue extends Me{constructor(t,e){super(),this._field=t,this._direction=e,this.type="orderBy"}static _create(t,e){return new Ue(t,e)}_apply(t){const e=(function(s,i,a){if(s.startAt!==null)throw new E(_.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(s.endAt!==null)throw new E(_.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new Gt(i,a)})(t._query,this._field,this._direction);return new tt(t.firestore,t.converter,(function(s,i){const a=s.explicitOrderBy.concat([i]);return new Yt(s.path,s.collectionGroup,a,s.filters.slice(),s.limit,s.limitType,s.startAt,s.endAt)})(t._query,e))}}function ko(n,t="asc"){const e=t,r=vt("orderBy",n);return Ue._create(r,e)}class $e extends Me{constructor(t,e,r){super(),this.type=t,this._limit=e,this._limitType=r}static _create(t,e,r){return new $e(t,e,r)}_apply(t){return new tt(t.firestore,t.converter,(function(r,s,i){return new Yt(r.path,r.collectionGroup,r.explicitOrderBy.slice(),r.filters.slice(),s,i,r.startAt,r.endAt)})(t._query,this._limit,this._limitType))}}function Fo(n){return $e._create("limit",n,"F")}function wn(n,t,e){if(typeof(e=W(e))=="string"){if(e==="")throw new E(_.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!Vi(t)&&e.indexOf("/")!==-1)throw new E(_.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${e}' contains a '/' character.`);const r=t.path.child(D.fromString(e));if(!O.isDocumentKey(r))throw new E(_.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return fn(n,new O(r))}if(e instanceof C)return fn(n,e._key);throw new E(_.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${Jt(e)}.`)}function bn(n,t){if(!Array.isArray(n)||n.length===0)throw new E(_.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${t.toString()}' filters.`)}function pr(n,t){const e=(function(s,i){for(const a of s)for(const d of a.getFlattenedFilters())if(i.indexOf(d.op)>=0)return d.op;return null})(n.filters,(function(s){switch(s){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}})(t.op));if(e!==null)throw e===t.op?new E(_.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${t.op.toString()}' filter.`):new E(_.INVALID_ARGUMENT,`Invalid query. You cannot use '${t.op.toString()}' filters with '${e.toString()}' filters.`)}class mo{convertValue(t,e="none"){switch(st(t)){case 0:return null;case 1:return t.booleanValue;case 2:return P(t.integerValue||t.doubleValue);case 3:return this.convertTimestamp(t.timestampValue);case 4:return this.convertServerTimestamp(t,e);case 5:return t.stringValue;case 6:return this.convertBytes(At(t.bytesValue));case 7:return this.convertReference(t.referenceValue);case 8:return this.convertGeoPoint(t.geoPointValue);case 9:return this.convertArray(t.arrayValue,e);case 11:return this.convertObject(t.mapValue,e);case 10:return this.convertVectorValue(t.mapValue);default:throw V(62114,{value:t})}}convertObject(t,e){return this.convertObjectMap(t.fields,e)}convertObjectMap(t,e="none"){const r={};return Vt(t,((s,i)=>{r[s]=this.convertValue(i,e)})),r}convertVectorValue(t){const e=t.fields?.[jt].arrayValue?.values?.map((r=>P(r.doubleValue)));return new B(e)}convertGeoPoint(t){return new q(P(t.latitude),P(t.longitude))}convertArray(t,e){return(t.values||[]).map((r=>this.convertValue(r,e)))}convertServerTimestamp(t,e){switch(e){case"previous":const r=Gn(t);return r==null?null:this.convertValue(r,e);case"estimate":return this.convertTimestamp(wt(t));default:return null}}convertTimestamp(t){const e=rt(t);return new T(e.seconds,e.nanos)}convertDocumentKey(t,e){const r=D.fromString(t);Z(er(r),9688,{name:t});const s=new It(r.get(1),r.get(3)),i=new O(r.popFirst(5));return s.isEqual(e)||be(`A document reference to ${i} refers to a different database (${s.projectId}/${s.database}), which is not supported. It will be treated as a reference in the current database (${e.projectId}/${e.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function go(n,t,e){let r;return r=n?n.toFirestore(t):t,r}class _o extends mo{constructor(t){super(),this.firestore=t}convertBytes(t){return new U(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new C(this.firestore,null,e)}}function Mo(n){(function(s){if(s.limitType==="L"&&s.explicitOrderBy.length===0)throw new E(_.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")})((n=Qt(n,tt))._query);const t=Re(n.firestore),e=new _o(n.firestore);return to(t,n._query).then((r=>{const s=r.map((i=>new dr(n.firestore,e,i.key,i,n.converter)));return n._query.limitType==="L"&&s.reverse(),new po(n,s)}))}function xo(n,t,e,...r){const s=Ce((n=Qt(n,C)).firestore);let i;return i=typeof(t=W(t))=="string"||t instanceof Pe?uo(s,"updateDoc",n._key,t,e,r):lo(s,"updateDoc",n._key,t),rr(Re(n.firestore),[i.toMutation(n._key,ct.exists(!0))])}function Lo(n,t){const e=ro(n=Qt(n,H)),r=go(n.converter,t),s=ao(Ce(n.firestore),"addDoc",e._key,r,e.converter!==null,{});return rr(Re(n.firestore),[s.toMutation(e._key,ct.exists(!1))]).then((()=>e))}function Uo(){return new Oe("serverTimestamp")}const Tn="4.17.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(function(){Qs(`${Fs}_lite`),Ut(new _t("firestore/lite",((t,{instanceIdentifier:e,options:r})=>{const s=t.getProvider("app").getImmediate(),i=new te(new Zs(t.getProvider("auth-internal")),new ni(s,t.getProvider("app-check-internal")),si(s,e),s);return r&&i._setSettings(r),i}),"PUBLIC").setMultipleInstances(!0)),ut("firestore-lite",Tn,""),ut("firestore-lite",Tn,"esm2020")})();export{Mo as A,Oo as B,_t as C,Vr as D,Rn as E,ft as F,Co as G,ko as H,Fo as I,xo as J,ro as K,Dn as L,Lo as M,Uo as N,Fs as S,Ut as _,wo as a,Ao as b,Cs as c,W as d,No as e,b as f,yo as g,Nn as h,Eo as i,Er as j,Pn as k,Ds as l,Tr as m,xs as n,Lt as o,kr as p,vo as q,ut as r,Vo as s,So as t,bo as u,To as v,Io as w,Ro as x,Ms as y,Do as z};
